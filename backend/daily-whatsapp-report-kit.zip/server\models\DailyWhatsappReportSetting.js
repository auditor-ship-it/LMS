import mongoose from 'mongoose';

/**
 * Single settings row for the 5:30 PM "Daily Sales Report" WhatsApp message.
 * key is always 'default' — one report, one sender, editable recipients.
 */
const dailyWhatsappReportSettingSchema = new mongoose.Schema(
    {
        key: { type: String, default: 'default', unique: true },
        enabled: { type: Boolean, default: true },
        /** IST time of day, "HH:MM" (24h). */
        sendTime: { type: String, default: '17:30' },
        /** All daily send times, IST "HH:MM" (e.g. 11:00 and 17:30). */
        sendTimes: { type: [String], default: undefined },
        /** Number that must be linked as the sender (digits, with country code). */
        fromNumber: { type: String, default: '919321774772' },
        /** Portal username whose own linked WhatsApp sends the report (empty = dedicated sender login). */
        senderUsername: { type: String, default: '' },
        senderLabel: { type: String, default: '' },
        /** Recipients (digits, with country code). */
        toNumbers: { type: [String], default: ['917738333136'] },
        /** WhatsApp groups the report is also posted to ({ id: '...@g.us', name }). */
        groups: { type: [{ id: String, name: String, _id: false }], default: [] },
        /** Daily Activity Summary total each person should reach (red below it). */
        activityTarget: { type: Number, default: 30 },
        /** Daily KAM connected calls each KAM should reach (red below it). */
        kamTarget: { type: Number, default: 20 },
        /** Sales people always listed in Activity Summary — shown with 0 when they did nothing. */
        teamUsers: { type: [String], default: undefined },
        /** KAMs always listed in the KAM table — shown with 0 when they made no calls. */
        kamUsers: { type: [String], default: undefined },
        /** IST date (YYYY-MM-DD) the scheduled report was last sent — prevents double sends. */
        lastSentDateKey: { type: String, default: '' },
        /** "YYYY-MM-DD HH:MM" of each scheduled send already made (last 30). */
        lastSentSlots: { type: [String], default: [] },
        /** Claimed while a scheduled send is in progress (multi-instance safety). */
        sendingSince: { type: Date, default: null },
        lastRun: {
            at: Date,
            trigger: String, // 'schedule' | 'manual'
            ok: Boolean,
            sentTo: [String],
            failed: [{ to: String, error: String, _id: false }],
            error: String,
        },
        updatedBy: { type: String, default: '' },
    },
    { timestamps: true, collection: 'daily_whatsapp_report_settings' }
);

export default mongoose.models.DailyWhatsappReportSetting ||
    mongoose.model('DailyWhatsappReportSetting', dailyWhatsappReportSettingSchema);
