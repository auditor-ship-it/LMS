import React, { useCallback, useEffect, useState } from 'react';
import { AlertCircle, CheckCircle, Loader, MessageCircle, RefreshCw, Send, Eye, LogOut, X } from 'lucide-react';
import { api } from '../../lib/apiClient';
import { formatIstDateTime } from '../../lib/istDateTime';

interface Settings {
    enabled: boolean;
    sendTime: string;
    /** All daily send times, IST HH:MM. */
    sendTimes?: string[];
    fromNumber: string;
    toNumbers: string[];
    activityTarget: number;
    kamTarget: number;
    teamUsers: string[];
    /** null = automatic (everyone who made KAM calls in the last 30 days). */
    kamUsers: string[] | null;
    /** WhatsApp groups the report is also posted to. */
    groups: WaGroup[];
    lastSentDateKey?: string;
    lastRun?: {
        at?: string;
        trigger?: string;
        ok?: boolean;
        sentTo?: string[];
        failed?: { to: string; error: string }[];
        error?: string;
    };
    updatedBy?: string;
}

interface WaSession {
    status: string;
    qrDataUrl?: string | null;
    connectedNumber?: string | null;
    connectedName?: string | null;
    lastError?: string | null;
    progressMessage?: string | null;
    connected?: boolean;
    canSend?: boolean;
}

interface WaGroup {
    id: string;
    name: string;
    size?: number;
}

const BASE = '/daily-whatsapp-report';

const fmtNum = (n?: string | null) => (n ? `+${String(n).replace(/\D/g, '')}` : '');
const sameNumber = (a?: string | null, b?: string | null) => {
    const x = String(a || '').replace(/\D/g, '');
    const y = String(b || '').replace(/\D/g, '');
    return !!x && !!y && x.slice(-10) === y.slice(-10);
};

export default function DailyWhatsAppReportModal({ onClose }: { onClose: () => void }) {
    const [settings, setSettings] = useState<Settings | null>(null);
    const [form, setForm] = useState({
        enabled: true, sendTimes: ['11:00', '17:30'] as string[], fromNumber: '', toNumbers: '',
        activityTarget: '30', kamTarget: '20', teamUsers: '', kamUsers: '',
    });
    const [wa, setWa] = useState<WaSession | null>(null);
    const [preview, setPreview] = useState('');
    const [previewImg, setPreviewImg] = useState<string | null>(null);
    const [busy, setBusy] = useState<'' | 'save' | 'send' | 'preview' | 'link' | 'logout'>('');
    const [notice, setNotice] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
    /** Groups ticked to receive the report (saved with Save). */
    const [selectedGroups, setSelectedGroups] = useState<WaGroup[]>([]);
    /** All groups the sender number is in — loaded on demand. */
    const [allGroups, setAllGroups] = useState<WaGroup[] | null>(null);
    const [groupSearch, setGroupSearch] = useState('');
    const [groupsLoading, setGroupsLoading] = useState(false);

    const loadGroups = async () => {
        setGroupsLoading(true);
        try {
            const r = await api.get<{ data: WaGroup[] }>(`${BASE}/groups`);
            setAllGroups(r.data);
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Could not load WhatsApp groups' });
        } finally {
            setGroupsLoading(false);
        }
    };

    const toggleGroup = (g: WaGroup) =>
        setSelectedGroups((cur) =>
            cur.some((x) => x.id === g.id) ? cur.filter((x) => x.id !== g.id) : [...cur, { id: g.id, name: g.name }]
        );

    const groupName = (id: string) =>
        selectedGroups.find((g) => g.id === id)?.name || settings?.groups?.find((g) => g.id === id)?.name || 'a group';
    const recipientLabel = (to: string) => (String(to).endsWith('@g.us') ? `group "${groupName(to)}"` : fmtNum(to));

    const applySettings = (s: Settings) => {
        setSettings(s);
        setSelectedGroups(s.groups || []);
        setForm({
            enabled: s.enabled,
            sendTimes: s.sendTimes?.length ? [...s.sendTimes] : [s.sendTime],
            fromNumber: fmtNum(s.fromNumber),
            toNumbers: (s.toNumbers || []).map(fmtNum).join(', '),
            activityTarget: String(s.activityTarget ?? 30),
            kamTarget: String(s.kamTarget ?? 20),
            teamUsers: (s.teamUsers || []).join(', '),
            kamUsers: (s.kamUsers || []).join(', '),
        });
    };

    const load = useCallback(async () => {
        try {
            const r = await api.get<{ data: { settings: Settings; session: WaSession } }>(BASE);
            applySettings(r.data.settings);
            setWa(r.data.session);
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Could not load settings' });
        }
    }, []);

    useEffect(() => { void load(); }, [load]);

    // While not linked, keep polling so the QR refreshes and "Connected" shows up after the scan.
    const linked = !!wa?.connected;
    useEffect(() => {
        if (linked) return;
        const t = setInterval(async () => {
            try {
                const r = await api.get<{ data: WaSession }>(`${BASE}/session`);
                setWa(r.data);
            } catch { /* ignore */ }
        }, 2000);
        return () => clearInterval(t);
    }, [linked]);

    const linkWhatsApp = async () => {
        setBusy('link');
        setNotice(null);
        try {
            const r = await api.post<{ data: WaSession }>(`${BASE}/session/start`);
            setWa(r.data);
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Could not start WhatsApp' });
        } finally {
            setBusy('');
        }
    };

    const logout = async () => {
        if (!window.confirm(`Log out ${fmtNum(wa?.connectedNumber) || 'this WhatsApp'} from the report sender?`)) return;
        setBusy('logout');
        try {
            await api.post(`${BASE}/session/logout`);
            const r = await api.post<{ data: WaSession }>(`${BASE}/session/start`);
            setWa(r.data);
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Could not log out' });
        } finally {
            setBusy('');
        }
    };

    const formToNumbers = () => form.toNumbers.split(/[,;\n]+/).map((s) => s.trim()).filter(Boolean);

    /** Save the form to the server; returns the saved settings (throws on error). */
    const persist = async () => {
        const r = await api.put<{ data: Settings }>(`${BASE}/settings`, {
            enabled: form.enabled,
            sendTimes: form.sendTimes.filter(Boolean),
            fromNumber: form.fromNumber,
            toNumbers: formToNumbers(),
            activityTarget: Number(form.activityTarget),
            kamTarget: Number(form.kamTarget),
            teamUsers: form.teamUsers,
            // Blank = automatic KAM list
            kamUsers: form.kamUsers.trim() ? form.kamUsers : null,
            groups: selectedGroups,
        });
        applySettings(r.data);
        return r.data;
    };

    const save = async () => {
        setBusy('save');
        setNotice(null);
        try {
            await persist();
            setNotice({ kind: 'ok', text: 'Saved.' });
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Could not save' });
        } finally {
            setBusy('');
        }
    };

    const loadPreview = async () => {
        setBusy('preview');
        try {
            const r = await api.get<{ data: { text: string; imageDataUrl: string | null } }>(`${BASE}/preview`);
            setPreview(r.data.text);
            setPreviewImg(r.data.imageDataUrl);
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Could not build preview' });
        } finally {
            setBusy('');
        }
    };

    const sendNow = async () => {
        // Use what is typed in the boxes — unsaved changes are saved first.
        const toList = [
            ...(dirty ? formToNumbers() : (settings?.toNumbers || []).map(fmtNum)),
            ...(dirty ? selectedGroups : settings?.groups || []).map((g) => `group "${g.name}"`),
        ];
        if (!toList.length) {
            setNotice({ kind: 'err', text: 'Add a "To" number or pick a WhatsApp group first.' });
            return;
        }
        if (!window.confirm(`Send today's report now to ${toList.join(', ')}?${dirty ? '\n\nYour changes will be saved first.' : ''}`)) return;
        setBusy('send');
        setNotice(null);
        try {
            if (dirty) await persist();
            const r = await api.post<{ message: string }>(`${BASE}/send-now`);
            setNotice({ kind: 'ok', text: r.message });
        } catch (e: any) {
            setNotice({ kind: 'err', text: e.message || 'Send failed' });
        } finally {
            setBusy('');
            // Refresh "last send" only — never overwrite what is typed in the form.
            try {
                const r = await api.get<{ data: { settings: Settings } }>(BASE);
                setSettings(r.data.settings);
            } catch { /* ignore */ }
        }
    };

    const wrongSender = linked && wa?.connectedNumber && settings?.fromNumber && !sameNumber(wa.connectedNumber, settings.fromNumber);
    const sendBlockedReason = busy
        ? busy === 'send' ? 'Sending…' : 'Please wait for the current action to finish.'
        : !linked
            ? `The sender WhatsApp is not connected. Scan the QR in "Sender WhatsApp" with ${fmtNum(settings?.fromNumber) || 'the From phone'}.`
            : wrongSender
                ? `The connected phone is ${fmtNum(wa?.connectedNumber)}, but "From" is ${fmtNum(settings?.fromNumber)}. Click "Log out / link a different number" and scan with ${fmtNum(settings?.fromNumber)}, or set "From" back to ${fmtNum(wa?.connectedNumber)} and Save.`
                : '';
    const dirty =
        !!settings &&
        (form.enabled !== settings.enabled ||
            [...form.sendTimes].sort().join() !== [...(settings.sendTimes?.length ? settings.sendTimes : [settings.sendTime])].sort().join() ||
            form.fromNumber !== fmtNum(settings.fromNumber) ||
            form.toNumbers !== (settings.toNumbers || []).map(fmtNum).join(', ') ||
            form.activityTarget !== String(settings.activityTarget ?? 30) ||
            form.kamTarget !== String(settings.kamTarget ?? 20) ||
            form.teamUsers !== (settings.teamUsers || []).join(', ') ||
            form.kamUsers !== (settings.kamUsers || []).join(', ') ||
            selectedGroups.map((g) => g.id).sort().join() !== (settings.groups || []).map((g) => g.id).sort().join());
    const last = settings?.lastRun;

    return (
        <div className="fixed inset-0 z-[100] bg-black/50 flex items-start justify-center overflow-y-auto p-3 sm:p-6" onClick={onClose}>
        <div className="bg-background rounded-xl shadow-2xl w-full max-w-5xl p-4 md:p-6 space-y-4" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5 text-green-600" />
                <h1 className="text-lg font-bold">Daily WhatsApp Report</h1>
                <button type="button" onClick={onClose} className="ml-auto p-1.5 rounded-lg hover:bg-secondary" aria-label="Close">
                    <X className="w-5 h-5" />
                </button>
            </div>
            <p className="text-sm text-muted-foreground">
                Every day at the set time (IST) the Activity Summary and NBD lead report is sent on WhatsApp from the
                linked number to the numbers below.
            </p>

            {notice && (
                <div className={`p-3 rounded-lg flex items-center gap-2 text-sm border ${notice.kind === 'ok' ? 'bg-green-500/10 border-green-500/20 text-green-700' : 'bg-red-500/10 border-red-500/20 text-red-600'}`}>
                    {notice.kind === 'ok' ? <CheckCircle className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
                    {notice.text}
                </div>
            )}

            <div className="grid md:grid-cols-2 gap-4">
                {/* Settings */}
                <div className="bg-white rounded-lg border p-4 space-y-3">
                    <h2 className="text-sm font-bold">Settings</h2>
                    <label className="flex items-center gap-2 text-sm">
                        <input type="checkbox" checked={form.enabled} onChange={(e) => setForm({ ...form, enabled: e.target.checked })} />
                        Send automatically every day
                    </label>
                    <div className="block text-sm">
                        <span className="text-xs text-muted-foreground">Send times every day (IST)</span>
                        <div className="mt-1 space-y-1.5">
                            {form.sendTimes.map((t, i) => (
                                <div key={i} className="flex items-center gap-2">
                                    <input type="time" value={t}
                                        onChange={(e) => setForm({ ...form, sendTimes: form.sendTimes.map((x, j) => (j === i ? e.target.value : x)) })}
                                        className="flex-1 border border-input rounded-lg px-3 py-1.5 text-sm" />
                                    {form.sendTimes.length > 1 && (
                                        <button type="button" onClick={() => setForm({ ...form, sendTimes: form.sendTimes.filter((_, j) => j !== i) })}
                                            className="p-1.5 rounded-lg border hover:bg-red-50 hover:text-red-600" aria-label="Remove time">
                                            <X className="w-3.5 h-3.5" />
                                        </button>
                                    )}
                                </div>
                            ))}
                            <button type="button" onClick={() => setForm({ ...form, sendTimes: [...form.sendTimes, '12:00'] })}
                                className="text-xs text-primary underline">+ Add another time</button>
                        </div>
                    </div>
                    <label className="block text-sm">
                        <span className="text-xs text-muted-foreground">From (WhatsApp number that sends)</span>
                        <input value={form.fromNumber} onChange={(e) => setForm({ ...form, fromNumber: e.target.value })}
                            placeholder="+91 93217 74772" className="mt-1 w-full border border-input rounded-lg px-3 py-1.5 text-sm" />
                    </label>
                    <label className="block text-sm">
                        <span className="text-xs text-muted-foreground">To (comma-separated for more than one)</span>
                        <textarea value={form.toNumbers} rows={2} onChange={(e) => setForm({ ...form, toNumbers: e.target.value })}
                            placeholder="+91 77383 33136" className="mt-1 w-full border border-input rounded-lg px-3 py-1.5 text-sm" />
                    </label>
                    <div className="text-sm space-y-1.5">
                        <span className="text-xs text-muted-foreground">WhatsApp groups (the sender number must be a member)</span>
                        {selectedGroups.length > 0 ? (
                            <div className="flex flex-wrap gap-1.5">
                                {selectedGroups.map((g) => (
                                    <span key={g.id} className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-50 border border-green-200 text-green-800 text-xs">
                                        {g.name}
                                        <button type="button" onClick={() => toggleGroup(g)} className="hover:text-red-600" aria-label={`Remove ${g.name}`}>
                                            <X className="w-3 h-3" />
                                        </button>
                                    </span>
                                ))}
                            </div>
                        ) : (
                            <p className="text-xs text-muted-foreground">No group selected.</p>
                        )}
                        {allGroups === null ? (
                            <button type="button" onClick={() => void loadGroups()} disabled={!linked || groupsLoading}
                                title={!linked ? 'Connect the sender WhatsApp first' : undefined}
                                className="px-3 py-1 rounded-lg border text-xs font-medium disabled:opacity-50 inline-flex items-center gap-1.5">
                                {groupsLoading && <Loader className="w-3.5 h-3.5 animate-spin" />} Choose groups
                            </button>
                        ) : (
                            <div className="border rounded-lg p-2 space-y-1.5">
                                <input value={groupSearch} onChange={(e) => setGroupSearch(e.target.value)} placeholder="Search groups…"
                                    className="w-full border border-input rounded-md px-2 py-1 text-xs" />
                                <div className="max-h-40 overflow-y-auto space-y-0.5">
                                    {allGroups
                                        .filter((g) => g.name.toLowerCase().includes(groupSearch.trim().toLowerCase()))
                                        .map((g) => (
                                            <label key={g.id} className="flex items-center gap-2 text-xs px-1 py-0.5 rounded hover:bg-slate-50 cursor-pointer">
                                                <input type="checkbox" checked={selectedGroups.some((x) => x.id === g.id)} onChange={() => toggleGroup(g)} />
                                                <span className="truncate">{g.name}</span>
                                                {g.size ? <span className="ml-auto text-muted-foreground">{g.size}</span> : null}
                                            </label>
                                        ))}
                                    {allGroups.length === 0 && <p className="text-xs text-muted-foreground">This number is not in any group.</p>}
                                </div>
                                <p className="text-[11px] text-muted-foreground">Tick the group, then click Save.</p>
                            </div>
                        )}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                        <label className="block text-sm">
                            <span className="text-xs text-muted-foreground">Daily activity target / person</span>
                            <input type="number" min={0} value={form.activityTarget} onChange={(e) => setForm({ ...form, activityTarget: e.target.value })}
                                className="mt-1 w-full border border-input rounded-lg px-3 py-1.5 text-sm" />
                        </label>
                        <label className="block text-sm">
                            <span className="text-xs text-muted-foreground">KAM connected target / day</span>
                            <input type="number" min={0} value={form.kamTarget} onChange={(e) => setForm({ ...form, kamTarget: e.target.value })}
                                className="mt-1 w-full border border-input rounded-lg px-3 py-1.5 text-sm" />
                        </label>
                    </div>
                    <label className="block text-sm">
                        <span className="text-xs text-muted-foreground">Sales team (always listed in Activity Summary, shown as 0 when no calls)</span>
                        <textarea value={form.teamUsers} rows={2} onChange={(e) => setForm({ ...form, teamUsers: e.target.value })}
                            placeholder="Gauri, Laveena, Sagar" className="mt-1 w-full border border-input rounded-lg px-3 py-1.5 text-sm" />
                    </label>
                    <label className="block text-sm">
                        <span className="text-xs text-muted-foreground">KAMs (always listed in KAM Calls). Leave blank = everyone who made KAM calls in the last 30 days</span>
                        <textarea value={form.kamUsers} rows={2} onChange={(e) => setForm({ ...form, kamUsers: e.target.value })}
                            placeholder="Automatic" className="mt-1 w-full border border-input rounded-lg px-3 py-1.5 text-sm" />
                    </label>
                    <button type="button" onClick={() => void save()} disabled={!dirty || busy === 'save'}
                        className="px-4 py-1.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium disabled:opacity-50">
                        {busy === 'save' ? 'Saving…' : 'Save'}
                    </button>
                    {last?.at && (
                        <div className={`text-xs pt-2 border-t ${last.ok ? 'text-green-700' : 'text-red-600'}`}>
                            Last {last.trigger === 'schedule' ? 'scheduled' : 'manual'} send: {formatIstDateTime(last.at)} —{' '}
                            {last.ok ? `sent to ${(last.sentTo || []).map(recipientLabel).join(', ')}` : last.error || 'failed'}
                        </div>
                    )}
                </div>

                {/* Sender link */}
                <div className="bg-white rounded-lg border p-4 space-y-3">
                    <h2 className="text-sm font-bold">Sender WhatsApp</h2>
                    {linked ? (
                        <>
                            <p className="text-sm text-green-700 flex items-center gap-1.5">
                                <CheckCircle className="w-4 h-4" />
                                Connected: {wa?.connectedName || ''} {fmtNum(wa?.connectedNumber)}
                            </p>
                            {wrongSender && (
                                <p className="text-xs text-red-600">
                                    This is not the "From" number ({fmtNum(settings?.fromNumber)}). Reports will not send until
                                    you link {fmtNum(settings?.fromNumber)} or change "From".
                                </p>
                            )}
                            <button type="button" onClick={() => void logout()} disabled={busy === 'logout'}
                                className="px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 disabled:opacity-50">
                                <LogOut className="w-3.5 h-3.5" /> Log out / link a different number
                            </button>
                        </>
                    ) : (
                        <div className="space-y-2 text-sm text-center">
                            <p>
                                On the phone with <strong>{fmtNum(settings?.fromNumber) || 'the sender number'}</strong>: WhatsApp →
                                Linked devices → Link a device → scan this QR.
                            </p>
                            {wa?.qrDataUrl ? (
                                <img src={wa.qrDataUrl} alt="WhatsApp QR code" className="w-56 h-56 mx-auto bg-white rounded-lg border" />
                            ) : wa && ['initializing', 'authenticated'].includes(wa.status) ? (
                                <p className="text-xs text-muted-foreground flex items-center justify-center gap-2">
                                    <Loader className="w-4 h-4 animate-spin" />{wa.progressMessage || 'Starting WhatsApp…'}
                                </p>
                            ) : null}
                            {wa?.lastError && <p className="text-xs text-red-600">{wa.lastError}</p>}
                            <button type="button" onClick={() => void linkWhatsApp()} disabled={busy === 'link'}
                                className="px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-medium inline-flex items-center gap-1.5 disabled:opacity-50">
                                <RefreshCw className="w-3.5 h-3.5" /> {wa?.qrDataUrl ? 'Get a fresh QR' : 'Connect WhatsApp (show QR)'}
                            </button>
                        </div>
                    )}
                </div>
            </div>

            {/* Preview + send */}
            <div className="bg-white rounded-lg border p-4 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                    <h2 className="text-sm font-bold">Today's report</h2>
                    {sendBlockedReason && busy !== 'send' && (
                        <p className="w-full order-last text-xs text-red-600 flex items-center gap-1.5">
                            <AlertCircle className="w-3.5 h-3.5 shrink-0" /> Send now is off: {sendBlockedReason}
                        </p>
                    )}
                    <div className="flex gap-2">
                        <button type="button" onClick={() => void loadPreview()} disabled={!!busy}
                            className="px-3 py-1.5 rounded-lg border text-xs font-medium flex items-center gap-1.5 disabled:opacity-50">
                            {busy === 'preview' ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Eye className="w-3.5 h-3.5" />} Preview
                        </button>
                        <button type="button" onClick={() => void sendNow()} disabled={!!sendBlockedReason}
                            title={sendBlockedReason || undefined}
                            className="px-3 py-1.5 rounded-lg bg-green-600 text-white text-xs font-medium flex items-center gap-1.5 disabled:opacity-50">
                            {busy === 'send' ? <Loader className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />} Send now
                        </button>
                    </div>
                </div>
                {previewImg ? (
                    <img src={previewImg} alt="Report preview" className="max-w-full border rounded-lg" />
                ) : preview ? (
                    <pre className="whitespace-pre-wrap text-xs bg-slate-50 border rounded-lg p-3 max-h-[28rem] overflow-y-auto font-sans">{preview}</pre>
                ) : (
                    <p className="text-xs text-muted-foreground">Click Preview to see exactly what will be sent. The report goes as an image of these tables, with the title and login link as the caption.</p>
                )}
            </div>
        </div>
        </div>
    );
}
