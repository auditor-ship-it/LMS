/**
 * Admin: Daily Sales Report on WhatsApp — settings, sender QR link, preview, send now.
 * Mounted at /api/daily-whatsapp-report (authenticateToken + requireAdmin).
 */
import express from 'express';
import { renderReportPng } from '../services/dailyReportImage.js';
import {
    buildReportTables,
    tablesToText,
    getSenderSession,
    getSenderStatus,
    listSenderGroups,
    getSettings,
    logoutSenderSession,
    sendDailyReport,
    startSenderSession,
    updateSettings,
} from '../services/dailyWhatsappReportService.js';

const router = express.Router();

router.get('/', async (_req, res) => {
    try {
        res.json({ success: true, data: { settings: await getSettings(), session: getSenderSession() } });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

/** Groups the linked sender WhatsApp belongs to — to pick e.g. "Quatre Leads Sales team". */
router.get('/groups', async (_req, res) => {
    try {
        res.json({ success: true, data: await listSenderGroups() });
    } catch (err) {
        const status = err.code === 'WHATSAPP_NOT_CONNECTED' ? 409 : 500;
        res.status(status).json({ success: false, code: err.code, error: err.message });
    }
});

router.put('/settings', async (req, res) => {
    try {
        const by = req.user?.agentName || req.user?.username || '';
        res.json({ success: true, data: await updateSettings(req.body || {}, by) });
    } catch (err) {
        res.status(err.status || 500).json({ success: false, error: err.message });
    }
});

/** Lightweight poll for the header button: is the sender connected / does it need a re-scan? */
router.get('/status', async (_req, res) => {
    try {
        res.json({ success: true, data: await getSenderStatus() });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

router.get('/session', (_req, res) => {
    res.json({ success: true, data: getSenderSession() });
});

router.post('/session/start', async (_req, res) => {
    try {
        res.json({ success: true, data: await startSenderSession() });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message, data: getSenderSession() });
    }
});

router.post('/session/logout', async (_req, res) => {
    try {
        res.json({ success: true, data: await logoutSenderSession() });
    } catch (err) {
        res.status(err.code === 'AGENT_LOGIN' ? 409 : 500).json({ success: false, code: err.code, error: err.message });
    }
});

router.get('/preview', async (req, res) => {
    try {
        const date = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.date || '')) ? req.query.date : undefined;
        const report = await buildReportTables(date);
        let imageDataUrl = null;
        try {
            imageDataUrl = `data:image/png;base64,${renderReportPng(report).toString('base64')}`;
        } catch (e) {
            console.error('[daily-report] preview image failed:', e.message);
        }
        res.json({ success: true, data: { text: tablesToText(report), imageDataUrl } });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

router.post('/send-now', async (_req, res) => {
    try {
        const result = await sendDailyReport({ trigger: 'manual' });
        const groupNames = new Map(((await getSettings()).groups || []).map((g) => [g.id, g.name]));
        const label = (to) => (groupNames.has(to) ? `group "${groupNames.get(to)}"` : String(to).endsWith('@g.us') ? 'a group' : `+${to}`);
        res.json({
            success: true,
            data: result,
            message: result.allDelivered
                ? `Report sent to ${result.sentTo.map(label).join(', ')}`
                : `Partly sent. Failed: ${result.failedTo.map((f) => `${label(f.to)} (${f.error})`).join('; ')}`,
        });
    } catch (err) {
        const status = ['WHATSAPP_NOT_CONNECTED', 'WRONG_SENDER', 'NO_RECIPIENTS', 'GROUP_NOT_FOUND'].includes(err.code) ? 409 : 500;
        res.status(status).json({ success: false, code: err.code, error: err.message });
    }
});

export default router;
