/**
 * Daily Sales Report on WhatsApp.
 *
 * Every day at the configured IST time (default 17:30) a text report goes from a
 * dedicated WhatsApp sender session (linked once by QR on the Daily Report page)
 * to the configured recipients. It contains:
 *   - Activity Summary — per person, same numbers as the dashboard card
 *   - NBD — leads received today per portal: attended (with status breakdown),
 *     ringing and unattended, plus who attended / who has them ringing
 *
 * The sender session is NOT any agent's personal WhatsApp — it is its own
 * session key, so linking it never logs an agent out.
 */
import DailyWhatsappReportSetting from '../models/DailyWhatsappReportSetting.js';
import ColdCallingLead from '../models/ColdCallingLead.js';
import { getActivitySummary } from './activitySummaryService.js';
import { getLeadAttentionSummary } from './leadAttentionSummaryService.js';
import { withColdCallingDateMatch } from './coldCallingService.js';
import { toISTDateKey } from '../utils/istDate.js';
import { canonicalOwnerLabel } from '../utils/employeeIdentity.js';
import { activityRowMatchesAgent } from './activitySummaryService.js';
import { MONTHLY_REPORT_USERS } from '../config/salesTeam.js';
import mongoose from 'mongoose';
import fs from 'fs/promises';
import os from 'os';
import path from 'path';
import { renderReportPng } from './dailyReportImage.js';
import {
    sendWhatsAppImage,
    getWhatsAppSession,
    listWhatsAppGroups,
    logoutWhatsAppSession,
    sendWhatsAppText,
    startWhatsAppSession,
} from './whatsappEngine.js';

/** Fixed session identity for the report sender (separate from every agent). */
export const REPORT_SENDER = Object.freeze({
    username: 'daily-report-sender',
    agentName: 'Daily Report Sender',
});

/**
 * Which WhatsApp login sends the report. settings.senderUsername = an agent's portal
 * username (e.g. 'gauri') reuses that agent's own linked WhatsApp; empty = the
 * dedicated report-sender login above. Updated on every getSettings().
 */
let currentSender = REPORT_SENDER;
function senderFromSettings(s) {
    const u = String(s?.senderUsername || '').trim().toLowerCase();
    if (!u || u === REPORT_SENDER.username) return REPORT_SENDER;
    return { username: u, agentName: s?.senderLabel || u };
}
/** True when the report uses an agent's personal WhatsApp (never log that out from here). */
export function senderIsAgentLogin() {
    return currentSender !== REPORT_SENDER;
}

const PORTAL_URL = (process.env.DAILY_REPORT_PORTAL_URL || 'https://sales.crystalgrp.xyz').trim().replace(/\/+$/, '');
/** Don't fire a scheduled report more than this long after its time (e.g. server was down). */
const LATE_WINDOW_MIN = 180;
/** A failed / in-flight scheduled send is retried after this long. */
const RETRY_AFTER_MS = 10 * 60 * 1000;

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export function digitsOnly(v) {
    let d = String(v || '').replace(/\D/g, '');
    if (d.length > 10 && d.startsWith('0')) d = d.replace(/^0+/, '');
    return d.length === 10 ? `91${d}` : d;
}

function sameNumber(a, b) {
    const x = digitsOnly(a);
    const y = digitsOnly(b);
    return !!x && !!y && x.slice(-10) === y.slice(-10);
}

export async function getSettings() {
    let s = await DailyWhatsappReportSetting.findOne({ key: 'default' }).lean();
    if (!s) {
        await DailyWhatsappReportSetting.updateOne(
            { key: 'default' },
            { $setOnInsert: { key: 'default' } },
            { upsert: true }
        );
        s = await DailyWhatsappReportSetting.findOne({ key: 'default' }).lean();
    }
    currentSender = senderFromSettings(s);
    // Rows saved before these fields existed don't get schema defaults from lean().
    return {
        ...s,
        senderUsername: currentSender.username,
        activityTarget: Number.isFinite(s.activityTarget) ? s.activityTarget : 30,
        kamTarget: Number.isFinite(s.kamTarget) ? s.kamTarget : 20,
        teamUsers: Array.isArray(s.teamUsers) ? s.teamUsers : [...MONTHLY_REPORT_USERS],
        groups: Array.isArray(s.groups) ? s.groups : [],
        // Several sends a day (IST "HH:MM"); older rows only have the single sendTime.
        sendTimes: Array.isArray(s.sendTimes) && s.sendTimes.length ? [...s.sendTimes].sort() : [s.sendTime || '17:30'],
        lastSentSlots: Array.isArray(s.lastSentSlots) ? s.lastSentSlots : [],
        kamUsers: Array.isArray(s.kamUsers) ? s.kamUsers : null, // null = auto (recent KAM callers)
    };
}

function cleanNameList(v) {
    const raw = Array.isArray(v) ? v : String(v || '').split(/[,;\n]+/);
    return [...new Set(raw.map((n) => String(n || '').trim()).filter(Boolean))];
}

export async function updateSettings(patch, byUser) {
    const $set = { updatedBy: byUser || '' };
    if (patch.enabled !== undefined) $set.enabled = !!patch.enabled;
    // sendTimes: ["11:00", "17:30"]; a lone sendTime (older clients) means one send a day.
    const times = patch.sendTimes !== undefined ? patch.sendTimes : patch.sendTime !== undefined ? [patch.sendTime] : null;
    if (times !== null) {
        const list = [...new Set((Array.isArray(times) ? times : String(times).split(/[,;\s]+/))
            .map((t) => String(t || '').trim()).filter(Boolean))].sort();
        if (!list.length || list.some((t) => !/^([01]\d|2[0-3]):[0-5]\d$/.test(t))) {
            const err = new Error('Send times must be HH:MM (24-hour), e.g. 11:00 and 17:30');
            err.status = 400;
            throw err;
        }
        $set.sendTimes = list;
        $set.sendTime = list[list.length - 1];
    }
    if (patch.fromNumber !== undefined) {
        const f = digitsOnly(patch.fromNumber);
        if (f.length < 11) {
            const err = new Error('Enter a valid "From" WhatsApp number');
            err.status = 400;
            throw err;
        }
        $set.fromNumber = f;
    }
    if (patch.toNumbers !== undefined) {
        const raw = Array.isArray(patch.toNumbers) ? patch.toNumbers : String(patch.toNumbers).split(/[,;\n]+/);
        // May be empty when the report goes only to groups (checked at send time).
        $set.toNumbers = [...new Set(raw.map(digitsOnly).filter((n) => n.length >= 11))];
    }
    if (patch.groups !== undefined) {
        const list = (Array.isArray(patch.groups) ? patch.groups : [])
            .filter((g) => g && /^[\d-]+@g\.us$/.test(String(g.id || '')))
            .map((g) => ({ id: String(g.id), name: String(g.name || g.id).slice(0, 200) }));
        $set.groups = [...new Map(list.map((g) => [g.id, g])).values()];
    }
    for (const k of ['activityTarget', 'kamTarget']) {
        if (patch[k] === undefined) continue;
        const n = Number(patch[k]);
        if (!Number.isInteger(n) || n < 0 || n > 1000) {
            const err = new Error('Targets must be whole numbers (0 or more)');
            err.status = 400;
            throw err;
        }
        $set[k] = n;
    }
    if (patch.teamUsers !== undefined) $set.teamUsers = cleanNameList(patch.teamUsers);
    const update = { $set };
    if (patch.kamUsers !== undefined) {
        const list = patch.kamUsers === null ? [] : cleanNameList(patch.kamUsers);
        // Empty = automatic KAM list (recent KAM callers)
        if (list.length) $set.kamUsers = list;
        else update.$unset = { kamUsers: 1 };
    }
    await DailyWhatsappReportSetting.updateOne({ key: 'default' }, update, { upsert: true });
    return getSettings();
}

// ---------------------------------------------------------------------------
// Sender session (QR link)
// ---------------------------------------------------------------------------

export function getSenderSession() {
    return getWhatsAppSession(currentSender);
}
/** WhatsApp groups the report sender number is a member of. */
export function listSenderGroups() {
    return listWhatsAppGroups(currentSender);
}
export function startSenderSession() {
    return startWhatsAppSession(currentSender);
}
export function logoutSenderSession() {
    if (senderIsAgentLogin()) {
        // Logging out here would also log the agent out of their own WhatsApp in the portal.
        const err = new Error(
            `The report is sent from ${currentSender.agentName}'s own WhatsApp. Log out from their WhatsApp in the portal instead.`
        );
        err.code = 'AGENT_LOGIN';
        return Promise.reject(err);
    }
    return logoutWhatsAppSession(REPORT_SENDER);
}

// ---------------------------------------------------------------------------
// Report content
// ---------------------------------------------------------------------------

function istDayBounds(dateKey) {
    return {
        start: new Date(`${dateKey}T00:00:00.000+05:30`),
        end: new Date(`${dateKey}T23:59:59.999+05:30`),
    };
}

function formatReportDate(dateKey) {
    const d = new Date(`${dateKey}T12:00:00+05:30`);
    return new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Kolkata',
        weekday: 'short',
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    }).format(d);
}

const nameOf = (raw) => canonicalOwnerLabel(raw || '') || 'Unassigned';


async function coldCallingByPerson(start, end) {
    const match = withColdCallingDateMatch(
        { assignment_status: { $in: ['allocated', 'attended'] } },
        start,
        end,
        'any'
    );
    return ColdCallingLead.aggregate([
        { $match: match },
        {
            $group: {
                _id: { $ifNull: ['$assigned_to_name', 'Unassigned'] },
                total: { $sum: 1 },
                attended: { $sum: { $cond: [{ $eq: ['$current_status', 'Done'] }, 1, 0] } },
                unattended: {
                    $sum: {
                        $cond: [
                            {
                                $and: [
                                    { $ne: [{ $ifNull: ['$attended', false] }, true] },
                                    { $in: [{ $ifNull: ['$current_status', 'Wait'] }, ['Wait', 'New']] },
                                ],
                            },
                            1,
                            0,
                        ],
                    },
                },
            },
        },
    ]);
}

/**
 * Drop numeric columns that are zero in every row (keeps the table phone-sized).
 * Column 0 (the label) and columns marked keep:true always stay.
 */
function pruneEmptyColumns(table) {
    const keepIdx = table.columns
        .map((c, i) => ({ c, i }))
        .filter(({ c, i }) => i === 0 || c.keep || table.rows.some((r) => { const v = cv(r[i]); return v !== 0 && v !== '' && v != null; }))
        .map(({ i }) => i);
    return {
        ...table,
        columns: keepIdx.map((i) => table.columns[i]),
        rows: table.rows.map((r) => keepIdx.map((i) => r[i])),
        totalRow: table.totalRow ? keepIdx.map((i) => table.totalRow[i]) : null,
    };
}

const num = (label, extra = {}) => ({ label, align: 'right', ...extra });

/** A cell is a plain value or { v, tone } — tone 'bad' = red (below target), 'warn' = orange. */
export const cv = (c) => (c && typeof c === 'object' ? c.v : c);
const bad = (v) => ({ v, tone: 'bad' });
const warnIf = (v) => (Number(v) > 0 ? { v, tone: 'warn' } : v);

/** KAM calls on Existing Leads for the day: Touch Base = connected, Ringing = not connected. */
async function kamCallsByPerson(start, end) {
    const db = mongoose.connection.db;
    const [leadRows, formRows] = await Promise.all([
        db.collection('existing_leads').aggregate([
            { $match: { 'followups.created_at': { $gte: start, $lte: end } } },
            { $unwind: '$followups' },
            { $match: { 'followups.created_at': { $gte: start, $lte: end } } },
            {
                $addFields: {
                    _ring: {
                        $or: [
                            { $eq: [{ $toLower: { $ifNull: ['$followups.followup_type', ''] } }, 'ringing'] },
                            { $eq: [{ $toUpper: { $ifNull: ['$followups.metadata.mode', ''] } }, 'RINGING'] },
                        ],
                    },
                },
            },
            {
                $group: {
                    _id: '$followups.created_by.name',
                    connected: { $sum: { $cond: ['$_ring', 0, 1] } },
                    ringing: { $sum: { $cond: ['$_ring', 1, 0] } },
                },
            },
        ]).toArray(),
        // KAM calling form submissions (KAM page) also count as connected calls.
        db.collection('kam_calls').aggregate([
            { $match: { call_date: { $gte: start, $lte: end } } },
            { $group: { _id: '$kam_name', connected: { $sum: 1 } } },
        ]).toArray(),
    ]);
    const map = new Map();
    for (const r of [...leadRows, ...formRows]) {
        if (!r._id) continue;
        const name = nameOf(r._id);
        const cur = map.get(name) || { connected: 0, ringing: 0 };
        cur.connected += r.connected || 0;
        cur.ringing += r.ringing || 0;
        map.set(name, cur);
    }
    return map;
}

/** People who logged KAM calls on Existing Leads in the last 30 days (auto KAM list). */
async function recentKamCallers(end) {
    const since = new Date(end.getTime() - 30 * 86_400_000);
    const names = await mongoose.connection.db.collection('existing_leads').aggregate([
        { $match: { 'followups.created_at': { $gte: since, $lte: end } } },
        { $unwind: '$followups' },
        { $match: { 'followups.created_at': { $gte: since, $lte: end } } },
        { $group: { _id: '$followups.created_by.name' } },
    ]).toArray();
    return [...new Set(names.map((r) => r._id).filter(Boolean).map(nameOf))];
}

/**
 * The report as tables: { title, tables: [{ title, columns, rows, totalRow, note }], link }.
 * Used by both the PNG renderer and the plain-text fallback.
 */
export async function buildReportTables(dateKey = toISTDateKey(new Date()), settingsIn = null) {
    const { start, end } = istDayBounds(dateKey);
    const settings = settingsIn || (await getSettings());
    const activityTarget = Number(settings.activityTarget) || 0;
    const kamTarget = Number(settings.kamTarget) || 0;

    const [activity, attention, cold, kam, autoKams] = await Promise.all([
        getActivitySummary(start, end).catch((e) => {
            console.error('[daily-report] activity summary failed:', e.message);
            return null;
        }),
        getLeadAttentionSummary({ role: 'admin' }, start.toISOString(), end.toISOString()).catch((e) => {
            console.error('[daily-report] NBD summary failed:', e.message);
            return null;
        }),
        coldCallingByPerson(start, end).catch((e) => {
            console.error('[daily-report] cold calling failed:', e.message);
            return null;
        }),
        kamCallsByPerson(start, end).catch((e) => {
            console.error('[daily-report] KAM calls failed:', e.message);
            return null;
        }),
        settings.kamUsers ? Promise.resolve(null) : recentKamCallers(end).catch(() => []),
    ]);

    const tables = [];

    // 1. Activity Summary — one row per person; team members with no activity show as 0
    if (activity) {
        const people = activity.filter((r) => (r.total || 0) > 0 || (r.kamCalls || 0) > 0 || (r.po || 0) > 0);
        for (const member of settings.teamUsers || []) {
            if (!people.some((r) => activityRowMatchesAgent(r.name, member))) {
                people.push({ name: nameOf(member), total: 0 });
            }
        }
        people.sort((x, y) => (y.total || 0) - (x.total || 0) || String(x.name).localeCompare(String(y.name)));
        const keys = ['newLeads', 'followups', 'followupsRinging', 'touchBase', 'tenderFollowups', 'kamCalls',
            'productNotApplicable', 'nonPotential', 'srfMql', 'sql', 'po', 'total'];
        const rows = people.map((r) => {
            const vals = keys.map((k) => Number(r[k]) || 0);
            const total = Number(r.total) || 0;
            const below = activityTarget > 0 && total < activityTarget && String(r.name).toLowerCase() !== 'unknown';
            return below ? [bad(r.name), ...vals.slice(0, -1), bad(total)] : [r.name, ...vals];
        });
        const totalRow = ['Team total', ...keys.map((_, i) => rows.reduce((acc, r) => acc + (Number(cv(r[i + 1])) || 0), 0))];
        const belowCount = rows.filter((r) => typeof r[0] === 'object').length;
        tables.push(pruneEmptyColumns({
            title: activityTarget
                ? `Activity Summary (target ${activityTarget}/day · ${rows.length - belowCount}/${rows.length} met)`
                : 'Activity Summary',
            columns: [
                { label: 'Name' }, num('Fresh Call'), num('Follow Up'), num('FU Ringing'), num('Touch Base'),
                num('Tender FU'), num('KAM Calls'), num('Prod N/A'), num('Non Pot.'), num('SRF/MQL'),
                num('SQL'), num('PO'), num('Total', { keep: true, bold: true }),
            ],
            rows,
            totalRow: rows.length ? totalRow : null,
            note: rows.length
                ? (activityTarget ? `Red = below the daily target of ${activityTarget}.` : '')
                : 'No activity logged today.',
        }));
    } else {
        tables.push({ title: 'Activity Summary', columns: [], rows: [], note: 'Could not load activity data.' });
    }

    // 1b. KAM calls — connected vs ringing, per KAM, against the KAM target
    if (kam) {
        const roster = settings.kamUsers || autoKams || [];
        const names = new Set([...kam.keys()]);
        for (const k of roster) {
            if (![...names].some((n) => activityRowMatchesAgent(n, k))) names.add(nameOf(k));
        }
        const kamRows = [...names]
            .map((name) => {
                const c = kam.get(name) || { connected: 0, ringing: 0 };
                const total = c.connected + c.ringing;
                const below = kamTarget > 0 && c.connected < kamTarget;
                return below ? [bad(name), total, bad(c.connected), c.ringing] : [name, total, c.connected, c.ringing];
            })
            .sort((x, y) => cv(y[2]) - cv(x[2]) || String(cv(x[0])).localeCompare(String(cv(y[0]))));
        const met = kamRows.filter((r) => typeof r[0] !== 'object').length;
        tables.push({
            title: kamTarget
                ? `KAM Calls (target ${kamTarget} connected/day · ${met}/${kamRows.length} met)`
                : 'KAM Calls',
            columns: [{ label: 'KAM' }, num('Calls'), num('Connected', { bold: true }), num('Not connected')],
            rows: kamRows,
            totalRow: kamRows.length
                ? ['Total', ...[1, 2, 3].map((i) => kamRows.reduce((acc, r) => acc + (Number(cv(r[i])) || 0), 0))]
                : null,
            note: kamRows.length
                ? 'Connected = Touch Base + KAM call form. Not connected = Ringing.' +
                  (kamTarget ? ` Red = below ${kamTarget} connected.` : '')
                : 'No KAM calls logged today.',
        });
    }

    // 2. NBD by source, 3. NBD person wise, 4. Attended status
    if (attention?.bySource) {
        const [im, ti, g] = attention.bySource;
        const coldRows = cold || [];
        const coldSum = (k) => coldRows.reduce((a, r) => a + (r[k] || 0), 0);
        // Attended leads by status, e.g. "SRF/MQL 5, Non Potential 4" — shown next to Attended.
        const statusText = (s) =>
            (s?.crmStageBreakdown || [])
                .filter((r) => Number(r?.count) > 0)
                .sort((a, b) => b.count - a.count)
                .map((r) => `${String(r._id || '').trim() || 'No status'} ${r.count}`)
                .join(', ') || '-';
        const srcRows = [
            ['IndiaMART', im?.totalLeads || 0, im?.attendedTotal || 0, statusText(im), im?.ringingTotal || 0, warnIf(im?.unattendedTotal || 0)],
            ['TradeIndia', ti?.totalLeads || 0, ti?.attendedTotal || 0, statusText(ti), ti?.ringingTotal || 0, warnIf(ti?.unattendedTotal || 0)],
            ['Google Ads', g?.totalLeads || 0, g?.attendedTotal || 0, statusText(g), g?.ringingTotal || 0, warnIf(g?.unattendedTotal || 0)],
        ];
        if (cold) srcRows.push(['Cold Calling', coldSum('total'), coldSum('attended'), '-', '-', warnIf(coldSum('unattended'))]);
        const n = (v) => (typeof cv(v) === 'number' ? cv(v) : 0);
        const sum = (i) => srcRows.reduce((a, r) => a + n(r[i]), 0);
        tables.push({
            title: 'NBD — Leads received today',
            columns: [
                { label: 'Source' }, num('Leads'), num('Attended'), { label: 'Status (attended)' },
                num('Ringing'), num('Unattended'),
            ],
            rows: srcRows,
            totalRow: ['Total', sum(1), sum(2), '', sum(4), sum(5)],
            note: 'Orange = leads still unattended.',
        });
    } else {
        tables.push({ title: 'NBD — Leads received today', columns: [], rows: [], note: 'Could not load NBD lead data.' });
    }

    return { title: `Daily Sales Report — ${formatReportDate(dateKey)}`, tables, link: `${PORTAL_URL}/` };
}

/** Monospace text version (WhatsApp ``` block) — fallback if the image can't be made. */
export function tablesToText(report) {
    const out = [`*${report.title}*`];
    for (const t of report.tables) {
        out.push('', `*${t.title}*`);
        if (!t.columns.length || !t.rows.length) {
            if (t.note) out.push(t.note);
            continue;
        }
        const body = [...t.rows, ...(t.totalRow ? [t.totalRow] : [])];
        const mark = (c) => {
            const tone = c && typeof c === 'object' ? c.tone : '';
            return String(cv(c)) + (tone === 'bad' ? ' !' : tone === 'warn' ? ' *' : '');
        };
        const all = [t.columns.map((c) => c.label), ...body].map((r) => r.map(mark));
        const widths = t.columns.map((_, i) => Math.max(...all.map((r) => r[i].length)));
        const fmt = (r) =>
            r.map((v, i) => (t.columns[i].align === 'right' ? v.padStart(widths[i]) : v.padEnd(widths[i]))).join(' | ');
        const rule = widths.map((w) => '-'.repeat(w)).join('-+-');
        const lines = [fmt(all[0]), rule, ...all.slice(1, 1 + t.rows.length).map(fmt)];
        if (t.totalRow) lines.push(rule, fmt(all[all.length - 1]));
        out.push('```' + lines.join('\n') + '```');
        if (t.note) out.push(`_${t.note.replace(/Red =/g, '! =').replace(/Orange =/g, '* =')}_`);
    }
    out.push('', `Login to view full details: ${report.link}`);
    return out.join('\n');
}

/** Plain-text report for one IST date (defaults to today). */
export async function buildDailyReport(dateKey) {
    return tablesToText(await buildReportTables(dateKey));
}

// ---------------------------------------------------------------------------
// Sending
// ---------------------------------------------------------------------------

/**
 * Send the report now through the report-sender session.
 * Refuses if the linked WhatsApp is not the configured "From" number.
 */
export async function sendDailyReport({ trigger = 'manual', dateKey, toOverride } = {}) {
    const settings = await getSettings();
    // Numbers + WhatsApp groups (group ids end in @g.us; a group saved by name only is resolved below).
    const groups = toOverride?.length ? [] : settings.groups || [];
    let to = toOverride?.length ? [...toOverride] : [...(settings.toNumbers || [])];
    const record = async (lastRun) => {
        await DailyWhatsappReportSetting.updateOne({ key: 'default' }, { $set: { lastRun } });
    };

    try {
        if (!to.length && !groups.length) {
            throw Object.assign(new Error('No "To" numbers or groups configured'), { code: 'NO_RECIPIENTS' });
        }

        // Restores the saved login if the server restarted since linking.
        let session = getSenderSession();
        if (session.status !== 'ready') {
            await startSenderSession();
            const deadline = Date.now() + 20000;
            while (Date.now() < deadline) {
                session = getSenderSession();
                if (session.status === 'ready' || session.status === 'qr' || session.status === 'disconnected') break;
                await new Promise((r) => setTimeout(r, 500));
            }
        }
        if (session.status !== 'ready') {
            throw Object.assign(
                new Error('Report sender WhatsApp is not linked. Open Daily WhatsApp Report and scan the QR.'),
                { code: 'WHATSAPP_NOT_CONNECTED' }
            );
        }
        if (session.connectedNumber && settings.fromNumber && !sameNumber(session.connectedNumber, settings.fromNumber)) {
            throw Object.assign(
                new Error(
                    `Linked WhatsApp is +${session.connectedNumber}, but "From" is set to +${settings.fromNumber}. Re-link the right phone or change "From".`
                ),
                { code: 'WRONG_SENDER' }
            );
        }

        // Groups saved by name only (no id yet): look up the id from the sender's groups and remember it.
        if (groups.some((g) => !g.id)) {
            const mine = await listSenderGroups();
            const norm = (v) => String(v || '').trim().toLowerCase();
            let changed = false;
            for (const g of groups) {
                if (g.id) continue;
                const hit = mine.find((m) => norm(m.name) === norm(g.name));
                if (!hit) {
                    throw Object.assign(
                        new Error(`The sender WhatsApp is not in a group named "${g.name}".`),
                        { code: 'GROUP_NOT_FOUND' }
                    );
                }
                g.id = hit.id;
                changed = true;
            }
            if (changed) await DailyWhatsappReportSetting.updateOne({ key: 'default' }, { $set: { groups } });
        }
        to = [...to, ...groups.map((g) => g.id)];

        const report = await buildReportTables(dateKey, settings);
        const text = tablesToText(report);
        const caption = `*${report.title}*
Login to view full details: ${report.link}`;

        // Preferred: the tables as one PNG. Fallback: monospace text tables.
        let result;
        let png = null;
        try {
            png = renderReportPng(report);
        } catch (e) {
            console.error('[daily-report] image render failed, sending text:', e.message);
        }
        if (png) {
            const file = path.join(os.tmpdir(), `daily-report-${dateKey || 'today'}-${Date.now()}.png`);
            await fs.writeFile(file, png);
            try {
                result = await sendWhatsAppImage(to.join(","), file, caption, currentSender);
            } finally {
                fs.unlink(file).catch(() => {});
            }
        } else {
            result = await sendWhatsAppText(to.join(","), text, currentSender);
        }
        await record({
            at: new Date(),
            trigger,
            ok: result.allDelivered,
            sentTo: result.sentTo,
            failed: result.failedTo,
            error: result.allDelivered ? '' : 'Some recipients did not confirm',
        });
        console.log(`📨 [daily-report] ${trigger} send → ${result.sentTo.join(', ') || 'none'}`);
        return { ...result, text };
    } catch (err) {
        await record({
            at: new Date(),
            trigger,
            ok: false,
            sentTo: [],
            failed: (err.results || []).map((r) => ({ to: r.to, error: r.error || '' })),
            error: err.message,
        }).catch(() => {});
        console.error(`❌ [daily-report] ${trigger} send failed:`, err.message);
        throw err;
    }
}

// ---------------------------------------------------------------------------
// Scheduler
// ---------------------------------------------------------------------------

function istNowParts(now = new Date()) {
    const parts = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        hourCycle: 'h23',
    }).formatToParts(now);
    const h = Number(parts.find((p) => p.type === 'hour')?.value);
    const m = Number(parts.find((p) => p.type === 'minute')?.value);
    return { dateKey: toISTDateKey(now), minutes: h * 60 + m };
}

async function schedulerTick() {
    const settings = await getSettings();
    if (!settings?.enabled) return;
    const { dateKey, minutes } = istNowParts();
    // The first send slot of today that is due (within the late window) and not yet sent.
    const slot = settings.sendTimes.find((t) => {
        const [hh, mm] = String(t).split(':').map(Number);
        const due = hh * 60 + mm;
        return minutes >= due && minutes - due <= LATE_WINDOW_MIN && !settings.lastSentSlots.includes(`${dateKey} ${t}`);
    });
    if (!slot) return;
    const slotKey = `${dateKey} ${slot}`;

    // Atomic claim so two server instances never both send.
    const claimed = await DailyWhatsappReportSetting.findOneAndUpdate(
        {
            key: 'default',
            lastSentSlots: { $ne: slotKey },
            $or: [{ sendingSince: null }, { sendingSince: { $lt: new Date(Date.now() - RETRY_AFTER_MS) } }],
        },
        { $set: { sendingSince: new Date() } },
        { new: true }
    );
    if (!claimed) return;

    try {
        await sendDailyReport({ trigger: 'schedule', dateKey });
        await DailyWhatsappReportSetting.updateOne(
            { key: 'default' },
            {
                $set: { lastSentDateKey: dateKey, sendingSince: null },
                $push: { lastSentSlots: { $each: [slotKey], $slice: -30 } },
            }
        );
    } catch {
        // Leave sendingSince set: acts as a back-off, retried after RETRY_AFTER_MS.
    }
}

// ---------------------------------------------------------------------------
// Sender health — keep the saved login alive and flag when a re-scan is needed
// ---------------------------------------------------------------------------

/** When the sender was last seen not connected (null while connected). */
let senderDownSince = null;

/**
 * Restore the saved WhatsApp login after a restart / dropped socket. If WhatsApp
 * has logged the device out, the session sits on a QR and the admin is alerted
 * (see getSenderStatus) to scan again — after which sending resumes on its own.
 */
async function senderHealthTick() {
    const settings = await getSettings();
    if (!settings?.enabled) return;
    let s = getSenderSession();
    if (s.status === 'idle' || s.status === 'disconnected') {
        s = await startSenderSession().catch(() => getSenderSession());
    }
    if (s.status === 'ready') {
        if (senderDownSince) console.log('✅ [daily-report] sender WhatsApp connected again');
        senderDownSince = null;
    } else if (!senderDownSince && s.status !== 'initializing' && s.status !== 'authenticated') {
        senderDownSince = new Date();
        console.warn(`⚠️ [daily-report] sender WhatsApp not connected (${s.status}) — re-scan needed`);
    }
}

/** Small status payload for the header button / alert. */
export async function getSenderStatus() {
    const settings = await getSettings();
    const s = getSenderSession();
    const connected = s.status === 'ready';
    const wrongSender = connected && s.connectedNumber && settings.fromNumber && !sameNumber(s.connectedNumber, settings.fromNumber);
    const reconnecting = s.status === 'initializing' || s.status === 'authenticated';
    return {
        enabled: !!settings.enabled,
        status: s.status,
        connected,
        connectedNumber: s.connectedNumber || null,
        fromNumber: settings.fromNumber,
        wrongSender: !!wrongSender,
        // Needs a human: enabled, and either not linked (not just mid-reconnect) or linked to the wrong phone.
        needsAttention: !!settings.enabled && (!!wrongSender || (!connected && !reconnecting)),
        downSince: senderDownSince,
        lastRun: settings.lastRun || null,
    };
}

let schedulerStarted = false;

export function startDailyWhatsappReportScheduler() {
    if (schedulerStarted || process.env.DAILY_WHATSAPP_REPORT_DISABLED === '1') return;
    // Only the production server sends / holds the sender WhatsApp. A local dev server on
    // the same database would otherwise fight it for the one WhatsApp connection.
    if (process.env.NODE_ENV !== 'production' && process.env.DAILY_WHATSAPP_REPORT_ENABLED !== '1') {
        console.log('⏸️ [daily-report] scheduler off (not production; set DAILY_WHATSAPP_REPORT_ENABLED=1 to force)');
        return;
    }
    schedulerStarted = true;
    console.log('⏰ [daily-report] WhatsApp daily report scheduler started');
    setInterval(() => {
        schedulerTick().catch((e) => console.error('[daily-report] tick failed:', e.message));
    }, 30_000);
    // Restore the sender login right away, then keep checking it.
    senderHealthTick().catch(() => {});
    setInterval(() => {
        senderHealthTick().catch((e) => console.error('[daily-report] sender check failed:', e.message));
    }, 2 * 60_000);
}
