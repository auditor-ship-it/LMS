import { useCallback, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { MessageCircle, AlertTriangle, X } from 'lucide-react';
import { api } from '../../lib/apiClient';
import DailyWhatsAppReportModal from './DailyWhatsAppReportModal';

interface SenderStatus {
    enabled: boolean;
    status: string;
    connected: boolean;
    connectedNumber: string | null;
    fromNumber: string;
    wrongSender: boolean;
    needsAttention: boolean;
}

const POLL_MS = 60_000;
const fmt = (n?: string | null) => (n ? `+${String(n).replace(/\D/g, '')}` : '');

/**
 * Admin header button for the 5:30 PM Daily WhatsApp Report.
 * Opens settings / QR / preview in a pop-up, and raises an alert (badge, banner,
 * browser notification) when the sender WhatsApp is logged out and needs a re-scan.
 */
export default function DailyReportButton() {
    const [open, setOpen] = useState(false);
    const [status, setStatus] = useState<SenderStatus | null>(null);
    const [bannerDismissed, setBannerDismissed] = useState(false);
    const notifiedRef = useRef(false);

    const refresh = useCallback(async () => {
        try {
            const r = await api.get<{ data: SenderStatus }>('/daily-whatsapp-report/status');
            setStatus(r.data);
        } catch {
            /* next poll retries */
        }
    }, []);

    useEffect(() => {
        void refresh();
        const t = setInterval(() => void refresh(), POLL_MS);
        return () => clearInterval(t);
    }, [refresh]);

    const alert = !!status?.needsAttention;
    const alertText = status?.wrongSender
        ? `Daily report WhatsApp is linked to ${fmt(status.connectedNumber)}, not ${fmt(status.fromNumber)}. Re-link to keep the 5:30 PM report going.`
        : `Daily report WhatsApp (${fmt(status?.fromNumber)}) is disconnected. Scan the QR again so the 5:30 PM report keeps sending.`;

    // Browser notification once per disconnect (if the admin allowed notifications).
    useEffect(() => {
        if (!alert) {
            notifiedRef.current = false;
            setBannerDismissed(false);
            return;
        }
        if (notifiedRef.current) return;
        notifiedRef.current = true;
        try {
            if ('Notification' in window && Notification.permission === 'granted') {
                const n = new Notification('Daily WhatsApp Report', { body: alertText });
                n.onclick = () => {
                    window.focus();
                    setOpen(true);
                };
            }
        } catch {
            /* notifications unavailable */
        }
    }, [alert, alertText]);

    const openModal = () => {
        setOpen(true);
        // Ask once so future disconnects can pop a desktop notification.
        try {
            if ('Notification' in window && Notification.permission === 'default') void Notification.requestPermission();
        } catch {
            /* ignore */
        }
    };

    return (
        <>
            <button
                type="button"
                onClick={openModal}
                className={`relative px-2.5 py-1 rounded-lg text-xs font-medium border transition-colors flex items-center gap-2 ${alert
                    ? 'border-red-300 bg-red-50 text-red-700 hover:bg-red-100'
                    : 'border-green-600/25 bg-green-600/10 text-green-700 hover:bg-green-600/15'}`}
                title={alert ? alertText : 'Daily WhatsApp Report — settings, preview, send now'}
            >
                <MessageCircle className="w-4 h-4" />
                <span className="hidden sm:inline">Daily Report</span>
                {alert && <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-red-600 ring-2 ring-white" />}
            </button>

            {/* Portal: the header uses backdrop-blur, which would trap 'fixed' pop-ups inside its strip. */}
            {alert && !bannerDismissed && !open && createPortal(
                <div className="fixed bottom-4 right-4 z-[90] max-w-sm bg-white border border-red-200 shadow-xl rounded-lg p-3 flex gap-2 text-sm">
                    <AlertTriangle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
                    <div className="space-y-2">
                        <p className="text-slate-800">{alertText}</p>
                        <button
                            type="button"
                            onClick={openModal}
                            className="px-3 py-1 rounded-md bg-green-600 text-white text-xs font-medium hover:bg-green-700"
                        >
                            Reconnect now
                        </button>
                    </div>
                    <button type="button" onClick={() => setBannerDismissed(true)} className="self-start p-0.5 text-slate-400 hover:text-slate-600" aria-label="Dismiss">
                        <X className="w-4 h-4" />
                    </button>
                </div>,
                document.body
            )}

            {open && createPortal(
                <DailyWhatsAppReportModal
                    onClose={() => {
                        setOpen(false);
                        void refresh();
                    }}
                />,
                document.body
            )}
        </>
    );
}
