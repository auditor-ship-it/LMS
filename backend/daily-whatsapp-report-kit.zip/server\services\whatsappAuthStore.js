import { initAuthCreds, BufferJSON, proto } from '@whiskeysockets/baileys';
import WhatsappAuthState from '../models/WhatsappAuthState.js';

const encode = (value) => JSON.stringify(value, BufferJSON.replacer);
const decode = (text) => JSON.parse(text, BufferJSON.reviver);

/**
 * Drop-in replacement for Baileys' `useMultiFileAuthState` that persists to
 * Mongo instead of local disk. See WhatsappAuthState for why disk is not an
 * option on this deployment.
 *
 * @param {string} userKey
 */
export async function useMongoAuthState(userKey) {
    const readDoc = async (keyId) => {
        const doc = await WhatsappAuthState.findOne({ userKey, keyId }).lean();
        if (!doc?.data) return null;
        try {
            return decode(doc.data);
        } catch {
            return null;
        }
    };

    const writeDoc = async (keyId, value) => {
        await WhatsappAuthState.updateOne(
            { userKey, keyId },
            { $set: { data: encode(value) } },
            { upsert: true }
        );
    };

    const removeDoc = (keyId) => WhatsappAuthState.deleteOne({ userKey, keyId });

    const creds = (await readDoc('creds')) || initAuthCreds();

    return {
        state: {
            creds,
            keys: {
                get: async (type, ids) => {
                    const out = {};
                    const docs = await WhatsappAuthState.find({
                        userKey,
                        keyId: { $in: ids.map((id) => `${type}-${id}`) },
                    }).lean();

                    const byKeyId = new Map(docs.map((d) => [d.keyId, d.data]));
                    for (const id of ids) {
                        const raw = byKeyId.get(`${type}-${id}`);
                        if (!raw) continue;
                        let value;
                        try {
                            value = decode(raw);
                        } catch {
                            continue;
                        }
                        // Baileys expects this one type back as a protobuf message,
                        // not the plain object JSON gives us.
                        if (type === 'app-state-sync-key' && value) {
                            value = proto.Message.AppStateSyncKeyData.fromObject(value);
                        }
                        out[id] = value;
                    }
                    return out;
                },
                set: async (data) => {
                    const ops = [];
                    for (const type of Object.keys(data)) {
                        for (const id of Object.keys(data[type])) {
                            const value = data[type][id];
                            const keyId = `${type}-${id}`;
                            if (value) {
                                ops.push({
                                    updateOne: {
                                        filter: { userKey, keyId },
                                        update: { $set: { data: encode(value) } },
                                        upsert: true,
                                    },
                                });
                            } else {
                                ops.push({ deleteOne: { filter: { userKey, keyId } } });
                            }
                        }
                    }
                    if (ops.length) await WhatsappAuthState.bulkWrite(ops, { ordered: false });
                },
            },
        },
        saveCreds: () => writeDoc('creds', creds),
        /** Wipe every stored record for this agent (explicit logout / loggedOut). */
        clearState: async () => {
            await WhatsappAuthState.deleteMany({ userKey });
        },
        removeCreds: () => removeDoc('creds'),
    };
}
