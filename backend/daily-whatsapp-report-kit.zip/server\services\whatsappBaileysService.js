import path from 'path';
import fs from 'fs/promises';
import { createHash } from 'crypto';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import { useMongoAuthState } from './whatsappAuthStore.js';

import makeWASocket, {
    DisconnectReason,
    Browsers,
    makeCacheableSignalKeyStore,
} from '@whiskeysockets/baileys';

const require = createRequire(import.meta.url);
const QRCode = require('qrcode');
const pino = require('pino');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const INTRO_BROCHURES = [
    { file: 'Crystal Group Corporate Profile - Brief.pdf', caption: 'Crystal Group Corporate Profile (Brief)' },
    { file: 'Crystal Group Corporate Profile - Detailed.pdf', caption: 'Crystal Group Corporate Profile (Detailed)' },
].map((b) => ({ ...b, path: path.resolve(__dirname, '../../assets/email-attachments', b.file) }));
const GOOGLE_REVIEW_QR_PATH = path.resolve(__dirname, '../../assets/google-review-qr.png');

const logger = pino({ level: process.env.WHATSAPP_LOG_LEVEL || 'warn' });

/** @typedef {'idle'|'initializing'|'qr'|'authenticated'|'ready'|'disconnected'} WhatsAppSessionStatus */

/** @type {Map<string, any>} */
const sessions = new Map();

/**
 * Per-agent caches that must outlive a socket: a recipient asks for a resend
 * (retry receipt) when it can't decrypt, and if the session object was rebuilt
 * in between, an empty cache leaves them on "Waiting for this message" forever.
 */
const durableCaches = new Map();

function durableCachesFor(userKey) {
    let c = durableCaches.get(userKey);
    if (!c) {
        const counters = new Map();
        c = {
            sentMessages: new Map(),
            retryCounters: {
                get: (k) => counters.get(k),
                set: (k, v) => {
                    counters.set(k, v);
                    if (counters.size > 500) counters.delete(counters.keys().next().value);
                },
                del: (k) => counters.delete(k),
                flushAll: () => counters.clear(),
            },
        };
        durableCaches.set(userKey, c);
    }
    return c;
}

export function resolveUserKey(userLike) {
    const username = String(userLike?.username || '')
        .trim()
        .toLowerCase();
    const userId = String(userLike?.userId || userLike?.id || '').trim();
    const raw = username || userId || 'anonymous';
    return raw.replace(/[^a-z0-9_-]/g, '_').slice(0, 64) || 'anonymous';
}

function sessionLabel(userLike, userKey) {
    return String(userLike?.agentName || userLike?.username || userKey || 'agent').trim() || userKey;
}

function emptySession(userKey, label) {
    return {
        sock: null,
        status: /** @type {WhatsAppSessionStatus} */ ('idle'),
        qrDataUrl: null,
        pairingCode: null,
        lastError: null,
        connectedNumber: null,
        connectedName: null,
        progressMessage: null,
        progressPercent: null,
        startPromise: null,
        userKey,
        label: label || userKey,
        lastActivityAt: Date.now(),
        reconnectAttempts: 0,
        relinkAttempts: 0,
        closing: false,
        acks: new Map(),
        ackErrors: new Map(),
        // Recently sent messages, so a recipient's retry request can be answered.
        sentMessages: durableCachesFor(userKey).sentMessages,
        retryCounters: durableCachesFor(userKey).retryCounters,
        auth: null,
        pendingSave: null,
    };
}

function getOrCreateSession(userLike) {
    const userKey = resolveUserKey(userLike);
    let s = sessions.get(userKey);
    if (!s) {
        s = emptySession(userKey, sessionLabel(userLike, userKey));
        sessions.set(userKey, s);
    } else {
        s.label = sessionLabel(userLike, userKey);
    }
    s.lastActivityAt = Date.now();
    return s;
}

function snapshot(s) {
    const connectedUi = s.status === 'ready' || s.status === 'authenticated';
    return {
        status: s.status,
        qrDataUrl: s.status === 'qr' ? s.qrDataUrl : null,
        pairingCode: s.status === 'qr' ? s.pairingCode : null,
        connectedNumber: s.connectedNumber,
        connectedName: s.connectedName,
        lastError: s.lastError,
        progressMessage: s.progressMessage,
        progressPercent: s.progressPercent,
        userKey: s.userKey,
        agentLabel: s.label,
        personal: true,
        engine: 'baileys',
        connected: connectedUi,
        canSend: s.status === 'ready',
    };
}

/** Digits-only E.164 body (no '+'), defaulting bare 10-digit inputs to India. */
export function normalizeNumber(phone) {
    let digits = String(phone || '').replace(/\D/g, '');
    if (!digits) return '';
    if (digits.length > 10 && digits.startsWith('0')) digits = digits.replace(/^0+/, '');
    return digits.length === 10 ? `91${digits}` : digits;
}

/**
 * The compose box accepts "7304524566, 9136134532". The old service ran the
 * whole string through a digits-only strip, producing one 20-digit chat id that
 * belonged to nobody — the send silently went nowhere.
 */
export function parseRecipients(raw) {
    const out = [];
    // Split on real separators only, so "+91 89790 90602" stays one number.
    for (const chunk of String(raw || '').split(/[,;/|\n]+/)) {
        // WhatsApp group ids ("1203...@g.us") pass through untouched.
        if (/^[\d-]+@g\.us$/.test(chunk.trim())) {
            out.push(chunk.trim());
            continue;
        }
        const digits = normalizeNumber(chunk);
        if (digits.length >= 10 && digits.length <= 15) {
            out.push(digits);
            continue;
        }
        // Too long to be one number: it was space-separated, split it again.
        if (digits.length > 15) {
            for (const piece of chunk.trim().split(/\s+/)) {
                const n = normalizeNumber(piece);
                if (n.length >= 10 && n.length <= 15) out.push(n);
            }
        }
    }
    return [...new Set(out)];
}

/**
 * Load this agent's auth state ONCE per session and reuse it across reconnects.
 *
 * Reloading it per socket looks harmless but is a race that breaks every scan.
 * Right after a successful link Baileys emits `creds.update` (an async Mongo
 * write) and then immediately closes the socket with `restartRequired`. If the
 * reconnect re-reads from Mongo, it can easily read before that write lands —
 * this deployment talks to an Atlas cluster on another continent at ~240ms RTT —
 * so the new socket comes up with the old, unregistered credentials and WhatsApp
 * answers 401. That surfaces as "scanned, but it never connects".
 *
 * Holding one in-memory state object removes the read entirely: Baileys mutates
 * that same object, so the reconnect always sees the freshly linked credentials
 * whether or not the database write has caught up yet.
 */
async function getAuthState(s) {
    if (!s.auth) {
        const { state, saveCreds, clearState } = await useMongoAuthState(s.userKey);
        s.auth = {
            state,
            saveCreds,
            clearState,
            keyStore: makeCacheableSignalKeyStore(state.keys, logger),
        };
    }
    return s.auth;
}

async function createSocket(s) {
    const { state, saveCreds, clearState, keyStore } = await getAuthState(s);

    // No `version` override: the WA Web version Baileys ships with matches its
    // protobufs. Forcing the newest live version can break message encryption.
    const sock = makeWASocket({
        logger,
        auth: {
            creds: state.creds,
            keys: keyStore,
        },
        // Pairing-code login only works with a concrete browser identity.
        browser: Browsers.ubuntu('Chrome'),
        // Never pull the agent's chat history: it is the single biggest source of
        // memory use and startup time, and this service only ever sends outbound.
        syncFullHistory: false,
        shouldSyncHistoryMessage: () => false,
        markOnlineOnConnect: false,
        generateHighQualityLinkPreview: false,
        // When a recipient cannot decrypt a message it asks us to resend it. If
        // this returns nothing the retry is dropped and their chat is stuck on
        // "Waiting for this message. This may take a while."
        getMessage: async (key) => s.sentMessages.get(key?.id)?.message || undefined,
        // Lets Baileys count resend attempts per message instead of looping.
        msgRetryCounterCache: s.retryCounters,
    });

    s.sock = sock;

    // WhatsApp confirms a message asynchronously, well after sendMessage() has
    // resolved. Recording every ack here (rather than attaching a listener per
    // send) means an ack that lands quickly cannot be missed by a late listener.
    sock.ev.on('messages.update', (updates) => {
        for (const u of updates || []) {
            const id = u?.key?.id;
            const status = Number(u?.update?.status ?? 0);
            if (!id || !status) continue;
            s.acks.set(id, Math.max(s.acks.get(id) || 0, status));
        }
        // Keep the map from growing without bound over a long-lived session.
        if (s.acks.size > 500) {
            for (const k of [...s.acks.keys()].slice(0, s.acks.size - 500)) s.acks.delete(k);
        }
    });

    // WhatsApp's server answers every outgoing message with <ack class="message">.
    // Baileys only inspects it for errors, and the receipt-driven statuses above
    // need the recipient (or our own phone) online, so they rarely arrive in time.
    sock.ws.on('CB:ack,class:message', (node) => {
        const id = node?.attrs?.id;
        if (!id) return;
        if (node.attrs.error) {
            s.ackErrors.set(id, String(node.attrs.error));
            console.warn(`WhatsApp: server rejected ${id} error=${node.attrs.error} (${s.userKey})`);
        } else {
            s.acks.set(id, Math.max(s.acks.get(id) || 0, SERVER_ACK));
        }
        if (s.ackErrors.size > 200) s.ackErrors.delete(s.ackErrors.keys().next().value);
    });

    sock.ev.on('creds.update', () => {
        s.pendingSave = saveCreds().catch((err) => {
            console.error(`WhatsApp: failed to persist credentials (${s.userKey}):`, err.message);
        });
    });

    sock.ev.on('connection.update', async (update) => {
        const { connection, qr, lastDisconnect } = update;

        if (qr) {
            try {
                s.qrDataUrl = await QRCode.toDataURL(qr, { margin: 1, width: 280 });
                s.status = 'qr';
                s.lastError = null;
                s.progressMessage = 'Scan this QR with your phone, or use a pairing code';
                s.progressPercent = null;
                console.log(`WhatsApp QR ready for ${s.label} (${s.userKey})`);
                // Opt-in: print a scannable QR straight into the server logs, so a
                // link can be diagnosed without the browser being involved at all.
                if (process.env.WHATSAPP_QR_TERMINAL === '1') {
                    console.log(await QRCode.toString(qr, { type: 'terminal', small: true }));
                }
            } catch (err) {
                s.lastError = err.message;
            }
        }

        if (connection === 'connecting' && s.status !== 'qr') {
            s.status = 'initializing';
            s.progressMessage = 'Connecting to WhatsApp...';
        }

        if (connection === 'open') {
            s.status = 'ready';
            s.qrDataUrl = null;
            s.pairingCode = null;
            s.lastError = null;
            s.progressMessage = null;
            s.progressPercent = 100;
            s.reconnectAttempts = 0;
            s.relinkAttempts = 0;
            s.connectedNumber = String(sock.user?.id || '').split(':')[0].split('@')[0] || null;
            s.connectedName = sock.user?.name || sock.user?.verifiedName || null;
            console.log(
                `WhatsApp ready for ${s.label}: ${s.connectedName || ''} ${s.connectedNumber || ''}`
            );
        }

        if (connection === 'close') {
            const statusCode =
                lastDisconnect?.error?.output?.statusCode ?? lastDisconnect?.error?.status ?? 0;
            s.sock = null;

            if (s.closing) return; // deliberate teardown

            const loggedOut = statusCode === DisconnectReason.loggedOut;

            if (loggedOut) {
                s.connectedNumber = null;
                s.connectedName = null;
                s.qrDataUrl = null;
                s.pairingCode = null;
                await clearState().catch(() => {});
                s.auth = null; // force a fresh, empty state for the next socket
                console.warn(`WhatsApp logged out (${s.userKey}) - credentials cleared`);

                // Clearing the stored credentials is only half of the recovery.
                // WhatsApp answers 401 for any half-written or superseded login,
                // which happens routinely on a first link, and without opening a
                // new socket here no fresh QR is ever produced: the panel just
                // sits on "Connecting to WhatsApp..." forever. The state was wiped
                // above, so this next socket starts from scratch and will emit a QR.
                s.relinkAttempts = (s.relinkAttempts || 0) + 1;
                if (s.relinkAttempts > 3) {
                    s.status = 'disconnected';
                    s.lastError =
                        'WhatsApp kept rejecting this login. Click Disconnect and try again.';
                    return;
                }

                s.status = 'initializing';
                s.lastError = null;
                s.progressMessage = 'Previous login expired - fetching a fresh QR...';
                setTimeout(() => {
                    if (s.sock || s.closing) return;
                    createSocket(s).catch((err) => {
                        s.status = 'disconnected';
                        s.lastError = err.message;
                    });
                }, 300);
                return;
            }

            // Everything else is transient. `restartRequired` (515) in particular is
            // what WhatsApp always sends immediately after a successful first scan:
            // if it is not reconnected here, the agent sees the scan accepted and
            // then nothing, which is exactly the "scanned but never connects" report.
            s.reconnectAttempts += 1;
            if (s.reconnectAttempts > 6) {
                s.status = 'disconnected';
                s.lastError = 'WhatsApp kept dropping the connection. Try connecting again.';
                console.warn(`WhatsApp giving up reconnect (${s.userKey})`);
                return;
            }

            s.status = 'initializing';
            s.progressMessage = 'Reconnecting to WhatsApp...';
            const delay =
                statusCode === DisconnectReason.restartRequired
                    ? 250
                    : Math.min(1000 * 2 ** (s.reconnectAttempts - 1), 15000);
            setTimeout(() => {
                if (s.sock || s.closing) return;
                createSocket(s).catch((err) => {
                    s.status = 'disconnected';
                    s.lastError = err.message;
                });
            }, delay);
        }
    });

    return sock;
}

// ---------------------------------------------------------------------------
// Session lifecycle
// ---------------------------------------------------------------------------

const LIVE_STATUSES = new Set(['initializing', 'qr', 'authenticated', 'ready']);

export function getWhatsAppSession(userLike) {
    return snapshot(getOrCreateSession(userLike));
}

export async function startWhatsAppSession(userLike) {
    const s = getOrCreateSession(userLike);
    if (s.status === 'ready' && s.sock) return snapshot(s);
    if (s.sock && LIVE_STATUSES.has(s.status)) return snapshot(s);

    if (!s.startPromise) {
        s.closing = false;
        s.reconnectAttempts = 0;
        s.relinkAttempts = 0;
        s.status = 'initializing';
        s.lastError = null;
        s.progressMessage = 'Connecting to WhatsApp...';
        s.startPromise = createSocket(s)
            .catch((err) => {
                s.status = 'disconnected';
                s.lastError = err.message;
                s.sock = null;
                console.error(`WhatsApp start failed (${s.userKey}):`, err.message);
            })
            .finally(() => {
                s.startPromise = null;
            });
    }

    // Give the socket a moment to produce a QR or restore a saved login, so a
    // returning agent usually sees "Connected" on the very first response.
    await Promise.race([s.startPromise, new Promise((r) => setTimeout(r, 2500))]);
    if (s.status === 'initializing') {
        await new Promise((r) => setTimeout(r, 1500));
    }
    return snapshot(s);
}

/**
 * Alternative to scanning: WhatsApp shows an 8-character code to type into
 * Linked devices -> "Link with phone number instead".
 */
export async function requestPairingCode(userLike, phone) {
    const s = getOrCreateSession(userLike);
    const number = normalizeNumber(phone);
    if (!number) {
        const err = new Error('Enter your own WhatsApp number to get a pairing code');
        err.code = 'INVALID_PHONE';
        throw err;
    }
    if (s.status === 'ready') return snapshot(s);

    if (!s.sock) await startWhatsAppSession(userLike);
    // requestPairingCode is only valid once the socket is live and unregistered.
    for (let i = 0; i < 20 && !s.sock; i += 1) {
        await new Promise((r) => setTimeout(r, 250));
    }
    if (!s.sock) {
        const err = new Error('WhatsApp session is not up yet. Try again in a moment.');
        err.code = 'WHATSAPP_NOT_CONNECTED';
        throw err;
    }
    if (s.sock.authState?.creds?.registered) return snapshot(s);

    const code = await s.sock.requestPairingCode(number);
    s.pairingCode = String(code || '').replace(/^(.{4})(.{4})$/, '$1-$2');
    s.status = 'qr';
    s.progressMessage = 'Enter this code on your phone: Linked devices > Link with phone number';
    console.log(`WhatsApp pairing code issued for ${s.label} (${s.userKey})`);
    return snapshot(s);
}

async function teardown(s, reason) {
    s.closing = true;
    // Flush any in-flight creds write before killing the socket — abrupt end
    // mid-save can corrupt Mongo auth and force a new QR on next connect.
    if (s.pendingSave) {
        try {
            await s.pendingSave;
        } catch {
            /* already logged in creds.update handler */
        }
        s.pendingSave = null;
    }
    const sock = s.sock;
    s.sock = null;
    try {
        sock?.end?.(undefined);
    } catch {
        /* socket already gone */
    }
    console.log(`WhatsApp session closed (${s.userKey}): ${reason}`);
}

export async function logoutWhatsAppSession(userLike) {
    const s = getOrCreateSession(userLike);
    try {
        if (s.sock) await s.sock.logout();
    } catch (err) {
        console.warn(`WhatsApp logout (${s.userKey}):`, err.message);
    }
    await teardown(s, 'user logout');
    try {
        // Prefer the session's own state; only hit Mongo if it was never loaded.
        const clear = s.auth?.clearState || (await useMongoAuthState(s.userKey)).clearState;
        await clear();
        s.auth = null;
    } catch (err) {
        console.warn(`WhatsApp clear state (${s.userKey}):`, err.message);
    }
    sessions.set(s.userKey, emptySession(s.userKey, s.label));
    return snapshot(sessions.get(s.userKey));
}

/**
 * Idle reaper.
 *
 * Linked (`ready`) sessions are NEVER reaped — they stay logged in until the
 * user clicks Disconnect / logout. Credentials live in Mongo, and killing a
 * live socket after a few quiet hours was causing badSession + QR every ~5–6h.
 *
 * Only stuck QR / initializing sockets are reaped after IDLE_MS to free memory.
 * Set WHATSAPP_IDLE_MS=0 (or "off") to disable even that.
 */
const IDLE_RAW = String(process.env.WHATSAPP_IDLE_MS ?? '').trim().toLowerCase();
const IDLE_DISABLED = IDLE_RAW === '0' || IDLE_RAW === 'off' || IDLE_RAW === 'false';
const IDLE_MS = IDLE_DISABLED
    ? 0
    : Math.max(Number(process.env.WHATSAPP_IDLE_MS) || 6 * 60 * 60 * 1000, 5 * 60 * 1000);
const REAP_INTERVAL_MS = 5 * 60 * 1000;

const reaperTimer = setInterval(() => {
    if (IDLE_DISABLED) return;
    const now = Date.now();
    for (const s of [...sessions.values()]) {
        if (!s.sock) continue;
        // Keep linked devices alive indefinitely (until intentional logout).
        if (s.status === 'ready') continue;
        if (now - (s.lastActivityAt || 0) < IDLE_MS) continue;
        const reason = `idle stuck ${s.status} ${Math.round((now - (s.lastActivityAt || 0)) / 60000)}m`;
        void teardown(s, reason).then(() => {
            sessions.set(s.userKey, emptySession(s.userKey, s.label));
        });
    }
}, REAP_INTERVAL_MS);
if (typeof reaperTimer.unref === 'function') reaperTimer.unref();

export async function shutdownAllWhatsAppSessions() {
    clearInterval(reaperTimer);
    await Promise.all([...sessions.values()].map((s) => teardown(s, 'server shutdown')));
}

// ---------------------------------------------------------------------------
// Sending
// ---------------------------------------------------------------------------

async function ensureConnected(userLike) {
    const s = getOrCreateSession(userLike);
    if (s.status === 'ready' && s.sock) return s;

    // A saved login usually restores in a couple of seconds, so it is worth
    // waiting here rather than making the agent re-open compose.
    if (!s.sock && !s.startPromise) await startWhatsAppSession(userLike);
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
        if (s.status === 'ready' && s.sock) return s;
        if (s.status === 'qr' || s.status === 'disconnected') break;
        await new Promise((r) => setTimeout(r, 300));
    }

    const err = new Error(
        s.status === 'qr'
            ? 'Your WhatsApp is not linked yet. Scan the QR (or use a pairing code), then send again.'
            : s.lastError || 'Your WhatsApp is not connected. Open compose and link your phone.'
    );
    err.code = 'WHATSAPP_NOT_CONNECTED';
    throw err;
}

/** proto.WebMessageInfo.Status: ERROR 0, PENDING 1, SERVER_ACK 2, DELIVERY_ACK 3, READ 4. */
const SERVER_ACK = 2;
const ACK_TIMEOUT_MS = Math.max(Number(process.env.WHATSAPP_ACK_TIMEOUT_MS) || 20000, 5000);
/**
 * The upload itself happens inside sendMessage(); this only waits for the server
 * ack afterwards. Two brochures × this must stay well under nginx's 120s timeout.
 */
const MEDIA_ACK_TIMEOUT_MS = Math.max(
    Number(process.env.WHATSAPP_MEDIA_ACK_TIMEOUT_MS) || 40000,
    ACK_TIMEOUT_MS
);

/**
 * Wait until WhatsApp's servers acknowledge a message.
 *
 * sendMessage() resolves once the message has been encrypted and handed to the
 * socket — NOT when WhatsApp has accepted it. Treating that as success is why a
 * send could report "done" while nothing ever arrived and nothing appeared in
 * the sender's own chat list. Only a SERVER_ACK means it actually left.
 */
async function waitForAck(s, id, timeoutMs = ACK_TIMEOUT_MS) {
    if (!id) {
        console.warn(`WhatsApp: send returned no message id (${s.userKey})`);
        return false;
    }
    const started = Date.now();
    const deadline = started + timeoutMs;
    while (Date.now() < deadline) {
        if (s.ackErrors.has(id)) {
            console.warn(`WhatsApp: ${id} rejected by server (${s.ackErrors.get(id)}) (${s.userKey})`);
            return false;
        }
        const status = s.acks.get(id) || 0;
        if (status >= SERVER_ACK) {
            console.log(
                `WhatsApp: ack status=${status} for ${id} in ${Date.now() - started}ms (${s.userKey})`
            );
            return true;
        }
        if (!s.sock) {
            console.warn(`WhatsApp: socket died before ack for ${id} (${s.userKey})`);
            return false;
        }
        await new Promise((r) => setTimeout(r, 250));
    }
    console.warn(
        `WhatsApp: NO ack for ${id} after ${timeoutMs}ms, last status=${s.acks.get(id) || 0} (${s.userKey})`
    );
    return false;
}

/**
 * Send, then report whether WhatsApp acknowledged it.
 *
 * A missing ack is deliberately NOT treated as a failure. If sendMessage() threw,
 * the send genuinely failed. If it did not, the message may well be on its way
 * and only the confirmation is missing — so it is reported as 'unconfirmed'
 * rather than aborting the rest of the sequence. Silence is reported as silence,
 * never as success.
 */
async function sendConfirmed(s, jid, content, label, timeoutMs = ACK_TIMEOUT_MS) {
    const sent = await s.sock.sendMessage(jid, content);
    const id = sent?.key?.id || null;
    if (id && sent?.message) {
        s.sentMessages.set(id, sent);
        if (s.sentMessages.size > 200) {
            s.sentMessages.delete(s.sentMessages.keys().next().value);
        }
    }
    const acked = await waitForAck(s, id, timeoutMs);
    if (!acked) console.warn(`WhatsApp: no server ack for ${label} (${s.userKey})`);
    return { id, acked, label };
}

/**
 * A socket can stay "open" while nothing it sends reaches WhatsApp (status stays 0,
 * init queries time out, Bad MAC). Waiting out every ack in the intro then runs past
 * nginx's 120s proxy timeout and the agent sees an HTML 504. Drop the socket (creds
 * kept) so the next send gets a fresh connection, and fail with a readable error.
 */
function stalledSessionError(s, userLike, label) {
    console.warn(`WhatsApp: session stalled on ${label}, recycling socket (${s.userKey})`);
    if (!s.recycling) {
        s.recycling = true;
        void teardown(s, 'stalled - no server ack').then(() => {
            sessions.set(s.userKey, emptySession(s.userKey, s.label));
            startWhatsAppSession(userLike).catch(() => {});
        });
    }
    const err = new Error(
        'Your WhatsApp is linked but not responding - WhatsApp did not accept the message. ' +
            'The connection has been restarted; try again in a minute. If it keeps failing, ' +
            'click Disconnect and scan the QR again (also remove the old device from ' +
            'WhatsApp > Linked devices on your phone).'
    );
    err.code = 'WHATSAPP_SESSION_STALLED';
    return err;
}

async function resolveJid(s, number) {
    if (String(number).endsWith('@g.us')) return number; // group: no number lookup
    let results;
    try {
        results = await s.sock.onWhatsApp(number);
    } catch (err) {
        // A failed lookup is not proof the number is bad, so fall through and let
        // the delivery ack be the judge rather than blocking a valid send.
        console.warn(`onWhatsApp lookup failed (${s.userKey}) for ${number}:`, err.message);
        return `${number}@s.whatsapp.net`;
    }
    const hit = results?.find?.((r) => r?.exists);
    if (hit?.jid) {
        console.log(
            `WhatsApp: ${number} -> jid=${hit.jid}${hit.lid ? ` lid=${hit.lid}` : ''} (${s.userKey})`
        );
        return hit.jid;
    }
    // An answered lookup with no match is definitive: stop instead of sending
    // into a chat id that belongs to nobody.
    const err = new Error(`${number} is not on WhatsApp`);
    err.code = 'NOT_ON_WHATSAPP';
    throw err;
}

const pause = (ms) => new Promise((r) => setTimeout(r, ms));

/** Groups this WhatsApp is a member of: [{ id: '...@g.us', name, size }], sorted by name. */
export async function listWhatsAppGroups(userLike) {
    const s = await ensureConnected(userLike);
    const groups = await s.sock.groupFetchAllParticipating();
    return Object.values(groups || {})
        .map((g) => ({ id: g.id, name: g.subject || g.id, size: g.participants?.length || 0 }))
        .sort((a, b) => a.name.localeCompare(b.name));
}

/**
 * Turn per-recipient outcomes into the payload the UI renders, and fail loudly
 * when nothing actually went out. Previously a send reported success whenever no
 * exception was thrown, which is how a message that never left could still show
 * as "done".
 */
function summarize(s, results) {
    const delivered = results.filter((r) => r.status === 'sent' || r.status === 'unconfirmed');
    if (!delivered.length) {
        const err = new Error(results[0]?.error || 'WhatsApp did not accept the message');
        err.code = 'WHATSAPP_SEND_FAILED';
        err.results = results;
        throw err;
    }
    return {
        results,
        to: results.map((r) => r.to).join(', '),
        sentTo: results.filter((r) => r.status === 'sent').map((r) => r.to),
        failedTo: results
            .filter((r) => r.status !== 'sent')
            .map((r) => ({ to: r.to, error: r.error || 'not confirmed' })),
        allDelivered: results.every((r) => r.status === 'sent'),
        from: s.connectedNumber,
        fromName: s.connectedName,
    };
}

/**
 * Locate a brochure without reading it into memory.
 *
 * Baileys streams media given a file path, so large PDFs never have to sit in
 * the JS heap on the small production instance.
 */
async function locatePdf(filePath) {
    try {
        const stat = await fs.stat(filePath);
        if (!stat.isFile()) return null;
        return { url: filePath, name: path.basename(filePath), bytes: stat.size };
    } catch {
        console.error(`WhatsApp: brochure missing on disk: ${filePath}`);
        return null;
    }
}

function buildIntroMessages(introSequence, agentName, connectedName) {
    const name = String(agentName || connectedName || 'Team').trim();
    const raw = String(introSequence || '')
        .replace(/\{agentName\}/g, name)
        .trim();
    const fallback = [
        `Hello Sir/Madam, I am ${name} from Crystal Group Of Companies`,
        'Please do let us know if any requirements',
    ];
    if (!raw) return fallback;

    const parts = raw
        .split(/\n\s*\n/)
        .map((part) => part.trim())
        .filter(Boolean);

    if (parts.length >= 2) return [parts[0], parts[1]];
    if (parts.length === 1) return [parts[0], fallback[1]];
    return fallback;
}

export async function sendWhatsAppText(phone, message, userLike) {
    const body = String(message || '').trim();
    if (!body) {
        const err = new Error('Message body is required');
        err.code = 'INVALID_MESSAGE';
        throw err;
    }
    const numbers = parseRecipients(phone);
    if (!numbers.length) {
        const err = new Error('Enter a valid recipient phone number');
        err.code = 'INVALID_PHONE';
        throw err;
    }

    const s = await ensureConnected(userLike);
    const results = [];
    for (const number of numbers) {
        try {
            const jid = await resolveJid(s, number);
            const ack = await sendConfirmed(s, jid, { text: body }, `the message to ${number}`);
            results.push({
                to: number,
                status: ack.acked ? 'sent' : 'unconfirmed',
                id: ack.id,
                error: ack.acked ? undefined : 'WhatsApp did not confirm this message',
            });
        } catch (err) {
            results.push({ to: number, status: 'failed', error: err.message });
        }
        if (numbers.length > 1) await pause(1200);
    }

    return summarize(s, results);
}

export async function sendWhatsAppImage(phone, filePath, caption, userLike) {
    const numbers = parseRecipients(phone);
    if (!numbers.length) {
        const err = new Error('Enter a valid recipient phone number');
        err.code = 'INVALID_PHONE';
        throw err;
    }
    const s = await ensureConnected(userLike);
    const mediaPath = filePath || GOOGLE_REVIEW_QR_PATH;
    const text = String(caption || '').trim();

    const results = [];
    for (const number of numbers) {
        try {
            const jid = await resolveJid(s, number);
            const ack = await sendConfirmed(
                s,
                jid,
                { image: { url: mediaPath }, caption: text || undefined },
                `the image to ${number}`,
                MEDIA_ACK_TIMEOUT_MS
            );
            results.push({
                to: number,
                status: ack.acked ? 'sent' : 'unconfirmed',
                id: ack.id,
                error: ack.acked ? undefined : 'WhatsApp did not confirm this image',
            });
        } catch (err) {
            results.push({ to: number, status: 'failed', error: err.message });
        }
        if (numbers.length > 1) await pause(1200);
    }

    return { ...summarize(s, results), media: path.basename(mediaPath) };
}

/** Intro sequence: 2 text messages + corporate profile PDFs (brief, detailed), from THIS agent's WhatsApp. */
export async function sendWhatsAppIntro(phone, agentName, introSequence, userLike) {
    const numbers = parseRecipients(phone);
    if (!numbers.length) {
        const err = new Error('Enter a valid recipient phone number');
        err.code = 'INVALID_PHONE';
        throw err;
    }

    const s = await ensureConnected(userLike);
    const [msg1, msg2] = buildIntroMessages(introSequence, agentName, s.connectedName);
    const brochures = [];
    const missingDocs = [];
    for (const b of INTRO_BROCHURES) {
        const found = await locatePdf(b.path);
        if (found) brochures.push({ ...found, caption: b.caption });
        else missingDocs.push(b.file);
    }

    const results = [];
    for (const number of numbers) {
        const parts = [];
        try {
            const jid = await resolveJid(s, number);
            const acks = [];
            const first = await sendConfirmed(s, jid, { text: msg1 }, `message 1 to ${number}`);
            if (!first.acked) throw stalledSessionError(s, userLike, `message 1 to ${number}`);
            acks.push(first);
            parts.push('Message 1');
            await pause(900);
            const second = await sendConfirmed(s, jid, { text: msg2 }, `message 2 to ${number}`);
            if (!second.acked) throw stalledSessionError(s, userLike, `message 2 to ${number}`);
            acks.push(second);
            parts.push('Message 2');
            await pause(700);

            for (const [i, doc] of brochures.entries()) {
                if (i > 0) await pause(700);
                acks.push(
                    await sendConfirmed(
                        s,
                        jid,
                        {
                            document: { url: doc.url },
                            mimetype: 'application/pdf',
                            fileName: doc.name,
                            caption: doc.caption,
                        },
                        `${doc.name} to ${number}`,
                        MEDIA_ACK_TIMEOUT_MS
                    )
                );
                parts.push(doc.name);
            }
            const unconfirmed = acks.filter((a) => !a.acked);
            const problems = [];
            if (unconfirmed.length) {
                problems.push(`WhatsApp did not confirm ${unconfirmed.length} of ${acks.length} items`);
            }
            if (missingDocs.length) problems.push(`missing on server: ${missingDocs.join(', ')}`);
            results.push({
                to: number,
                status: problems.length ? 'unconfirmed' : 'sent',
                parts,
                error: problems.length ? problems.join('; ') : undefined,
            });
        } catch (err) {
            if (err.code === 'WHATSAPP_SESSION_STALLED') throw err;
            // Report exactly how far the sequence got: a lead that received the
            // intro but not the brochure must not look like a clean success.
            results.push({
                to: number,
                status: parts.length ? 'partial' : 'failed',
                parts,
                error: err.message,
            });
        }
        if (numbers.length > 1) await pause(1500);
    }

    return { ...summarize(s, results), sentBy: s.label };
}

/**
 * Send the user's OWN message (and optional attachments) to one or more numbers.
 * attachments: [{ filename, contentType, content(base64) }] — images go as photos, videos as
 * video, everything else as documents. The text is sent first, files follow.
 */
export async function sendWhatsAppCustom(phone, { text = '', attachments = [], includeBrochures = false } = {}, userLike) {
    const body = String(text || '').trim();
    const files = (attachments || []).filter((f) => f && f.filename && f.content);
    if (!body && !files.length && !includeBrochures) {
        const err = new Error('Message text or an attachment is required');
        err.code = 'INVALID_MESSAGE';
        throw err;
    }
    const numbers = parseRecipients(phone);
    if (!numbers.length) {
        const err = new Error('Enter a valid recipient phone number');
        err.code = 'INVALID_PHONE';
        throw err;
    }

    const s = await ensureConnected(userLike);
    const brochures = [];
    if (includeBrochures) {
        // A file the user attached that is byte-for-byte a standard brochure is sent once, not twice.
        const sha1 = (buf) => createHash('sha1').update(buf).digest('hex');
        const attached = new Set(files.map((f) => sha1(Buffer.from(f.content, 'base64'))));
        for (const b of INTRO_BROCHURES) {
            const found = await locatePdf(b.path);
            if (!found) continue;
            const same = attached.size && attached.has(sha1(await fs.readFile(found.url)));
            if (!same) brochures.push({ ...found, caption: b.caption });
        }
    }
    const results = [];
    for (const number of numbers) {
        const parts = [];
        try {
            const jid = await resolveJid(s, number);
            const acks = [];
            if (body) {
                const first = await sendConfirmed(s, jid, { text: body }, `message to ${number}`);
                if (!first.acked) throw stalledSessionError(s, userLike, `message to ${number}`);
                acks.push(first);
                parts.push('Message');
            }
            for (const f of files) {
                await pause(700);
                const buffer = Buffer.from(f.content, 'base64');
                const type = String(f.contentType || '').toLowerCase();
                const content = type.startsWith('image/')
                    ? { image: buffer, mimetype: type }
                    : type.startsWith('video/')
                      ? { video: buffer, mimetype: type }
                      : { document: buffer, mimetype: type || 'application/octet-stream', fileName: f.filename };
                acks.push(await sendConfirmed(s, jid, content, `${f.filename} to ${number}`, MEDIA_ACK_TIMEOUT_MS));
                parts.push(f.filename);
            }
            for (const doc of brochures) {
                await pause(700);
                acks.push(
                    await sendConfirmed(
                        s,
                        jid,
                        { document: { url: doc.url }, mimetype: 'application/pdf', fileName: doc.name, caption: doc.caption },
                        `${doc.name} to ${number}`,
                        MEDIA_ACK_TIMEOUT_MS
                    )
                );
                parts.push(doc.name);
            }
            const unconfirmed = acks.filter((a) => !a.acked);
            results.push({
                to: number,
                status: unconfirmed.length ? 'unconfirmed' : 'sent',
                parts,
                error: unconfirmed.length ? `WhatsApp did not confirm ${unconfirmed.length} of ${acks.length} items` : undefined,
            });
        } catch (err) {
            if (err.code === 'WHATSAPP_SESSION_STALLED') throw err;
            results.push({ to: number, status: parts.length ? 'partial' : 'failed', parts, error: err.message });
        }
        if (numbers.length > 1) await pause(1500);
    }
    return { ...summarize(s, results), sentBy: s.label };
}

export { GOOGLE_REVIEW_QR_PATH };
