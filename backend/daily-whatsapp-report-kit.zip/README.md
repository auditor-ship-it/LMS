# Daily WhatsApp Report — build kit

How to add the "Daily Sales Report on WhatsApp" feature (built in **S-Automation / Sales OS**) to another Node + React portal.

**What it does:** at fixed IST times (e.g. 11:00 and 17:30) the server builds a report from your database, draws it as a PNG of tables, and posts it to a WhatsApp group and/or phone numbers from a WhatsApp account linked by QR. Admins manage it from a pop-up opened by a header button. The button turns red, with a banner and a browser notification, when the WhatsApp login drops and needs a re-scan.

See `sample/report-sample.png` for what the group receives.

---

## 1. What's in this zip

| Path | What it is | Reuse as-is? |
|---|---|---|
| `server/services/whatsappBaileysService.js` | WhatsApp connection per user (QR / pairing code), send text/image, **groups** (`listWhatsAppGroups`, `...@g.us` recipients), delivery-ack checks | Yes (brochure / Google-review bits are Sales-OS extras; harmless) |
| `server/services/whatsappAuthStore.js` + `server/models/WhatsappAuthState.js` | Stores WhatsApp login keys in MongoDB, so logins survive restarts and deploys | Yes |
| `server/services/whatsappEngine.js` | Picks the WhatsApp backend. Keep `WHATSAPP_ENGINE=baileys`. It only imports `whatsappWebService.js` (not included) when the engine is `web` | Yes |
| `server/services/dailyWhatsappReportService.js` | Settings, **report data**, sending, scheduler, connection watchdog | **Partly.** Replace the data section (§4) |
| `server/services/dailyReportImage.js` | Draws the tables into a PNG (`@napi-rs/canvas`, no browser) | Yes |
| `server/models/DailyWhatsappReportSetting.js` | The single settings document | Yes |
| `server/routes/dailyWhatsappReport.js` | Admin API used by the pop-up | Yes |
| `client/components/DailyReportButton.tsx` | Header button, red alert badge, banner, browser notification | Yes (fix imports, §6) |
| `client/components/DailyWhatsAppReportModal.tsx` | Pop-up: settings, QR, groups, preview, Send now | Yes (fix imports, §6) |
| `.env` | Environment values (see §8 before using) | Edit |

## 2. Dependencies

Server (`package.json`, ES modules: `"type": "module"`):

```
npm i @whiskeysockets/baileys@7.0.0-rc14 @napi-rs/canvas@^1.0.9 qrcode@^1.5.4 pino@^9.14.0 mongoose express
```

Client: `react`, `lucide-react`, Tailwind CSS (the components use Tailwind classes).

**Linux server fonts:** the PNG uses the server's installed fonts. If none are installed, text renders as boxes. Install one, e.g. `apt install fonts-dejavu-core`.

**No API keys are needed.** WhatsApp works through a QR-linked device (like WhatsApp Web), not the paid WhatsApp Business API.

## 3. How it fits together

```
 header button ──► pop-up (settings, QR, groups, preview, Send now)
        │                    │
        │ GET /status        │ /api/daily-whatsapp-report/*  (admin only)
        ▼                    ▼
 dailyWhatsappReport.js (route) ──► dailyWhatsappReportService.js
                                       ├─ buildReportTables(dateKey)  ← YOUR DATA (§4)
                                       ├─ renderReportPng(report)     ← dailyReportImage.js
                                       ├─ sendDailyReport()           ← whatsappBaileysService.js
                                       └─ scheduler (every 30 s) + watchdog (every 2 min)
                                                      │
                                     MongoDB: daily_whatsapp_report_settings,
                                              whatsapp auth state (login keys)
```

## 4. The report data (the part you must change)

`buildReportTables(dateKey, settings)` in `dailyWhatsappReportService.js` returns:

```js
{
  title: 'Daily Sales Report — Wed, 04 Nov 2026',
  link:  'https://your-portal/',
  tables: [
    {
      title: 'Activity Summary (target 30/day · 2/10 met)',
      columns: [{ label: 'Name' }, { label: 'Calls', align: 'right' }, { label: 'Total', align: 'right', bold: true, keep: true }],
      rows: [
        [{ v: 'Gauri', tone: 'bad' }, 12, { v: 18, tone: 'bad' }],  // tone 'bad' = red cell
        ['Laveena', 30, 31],
      ],
      totalRow: ['Team total', 42, 49],                             // optional, green row
      note: 'Red = below the daily target of 30.',                  // optional, grey text under table
    },
  ],
}
```

- A cell is a plain value, or `{ v, tone }`, where `tone: 'bad'` is red (below target) and `'warn'` is orange (e.g. unattended leads).
- `pruneEmptyColumns(table)` drops numeric columns that are 0 for everyone. `keep: true` keeps a column anyway.
- The Sales OS data sources inside it (`getActivitySummary`, `getLeadAttentionSummary`, cold-calling and KAM-call aggregations, `canonicalOwnerLabel`, `MONTHLY_REPORT_USERS`) are specific to Sales OS. **Delete those imports and write your own queries** that fill tables in the shape above. Keep the helpers `cv`, `bad`, `warnIf`, `num`, `pruneEmptyColumns` and `tablesToText`.
- `istDayBounds(dateKey)` gives the IST day as `{ start, end }` Date objects for your queries.
- Sales OS rules, if you want the same ones:
  - **Team:** people with no activity still appear as a 0 row from `settings.teamUsers`; anyone below `settings.activityTarget` is red.
  - **KAM:** Touch Base = connected, Ringing = not connected; red below `settings.kamTarget`.
  - **NBD per lead source:** Leads, Attended, Status (attended), Ringing, Unattended (orange when above 0).

Check the result locally with `GET /api/daily-whatsapp-report/preview`, or call `buildReportTables()` and `renderReportPng()` from a small script and open the PNG.

## 5. Server wiring

In your main server file:

```js
import { authenticateToken, requireAdmin } from './middleware/auth.js';   // your auth
import dailyWhatsappReportRouter from './routes/dailyWhatsappReport.js';

app.use('/api/daily-whatsapp-report', authenticateToken, requireAdmin, dailyWhatsappReportRouter);

// after app.listen(...) and after mongoose is connected:
setTimeout(() => {
  import('./services/dailyWhatsappReportService.js')
    .then((m) => m.startDailyWhatsappReportScheduler())
    .catch((e) => console.warn('[daily-report] scheduler start skipped:', e?.message || e));
}, 20_000);

// on SIGTERM, close WhatsApp sockets cleanly (does NOT log out):
import('./services/whatsappEngine.js').then((m) => m.shutdownAllWhatsAppSessions?.());
```

API (all admin-only):

| Method | Path | Purpose |
|---|---|---|
| GET | `/` | settings + sender session |
| PUT | `/settings` | save settings (validated) |
| GET | `/status` | small payload for the header button (`needsAttention`) |
| GET | `/session` · POST `/session/start` · POST `/session/logout` | QR link / status / unlink |
| GET | `/groups` | groups the sender number belongs to |
| GET | `/preview?date=YYYY-MM-DD` | `{ text, imageDataUrl }` |
| POST | `/send-now` | send immediately |

## 6. Client wiring

1. Copy both components into your app.
2. Fix three imports to match your app:
   - `api` from `lib/apiClient`: a fetch wrapper with `get`, `post` and `put`. It must send the auth token, return the parsed JSON body, and throw `Error(body.error)` on non-2xx.
   - `formatIstDateTime(date)`: any date formatter.
   - `createPortal` (react-dom), used by the button.
3. Render it in your header for admins only: `{isAdmin && <DailyReportButton />}`.

## 7. Settings (MongoDB collection `daily_whatsapp_report_settings`, one doc `key: 'default'`)

| Field | Meaning |
|---|---|
| `enabled` | automatic sending on/off |
| `sendTimes` | `["11:00","17:30"]`, IST times; each time sends once a day |
| `lastSentSlots` | `"YYYY-MM-DD HH:MM"` of sends already made (stops double sends) |
| `senderUsername` | empty = dedicated "report sender" login (scan its QR in the pop-up); or a portal **username** to reuse that user's own linked WhatsApp |
| `fromNumber` | number the linked WhatsApp must be. If it doesn't match, the send is refused |
| `toNumbers` | phone numbers (digits with country code, e.g. `919876543210`) |
| `groups` | `[{ id: '1203…@g.us', name }]`. An entry saved with only a `name` gets its id looked up on first send |
| `activityTarget`, `kamTarget`, `teamUsers`, `kamUsers` | Sales OS report rules (§4) |
| `lastRun` | result of the last send (shown in the pop-up) |

## 8. Environment (`.env` in this zip)

| Variable | Needed | Notes |
|---|---|---|
| `MONGODB_URI` | yes | **The value in this zip is the LIVE Sales OS production database.** |
| `NODE_ENV=production` | yes, on the live server | The scheduler and watchdog only run when this is `production` (or `DAILY_WHATSAPP_REPORT_ENABLED=1`) |
| `WHATSAPP_ENGINE=baileys` | recommended | default |
| `DAILY_REPORT_PORTAL_URL` | yes | link printed under the report |
| `DAILY_WHATSAPP_REPORT_DISABLED=1` | optional | turn the scheduler off |
| `WHATSAPP_ACK_TIMEOUT_MS`, `WHATSAPP_MEDIA_ACK_TIMEOUT_MS`, `WHATSAPP_LOG_LEVEL` | optional | tuning / logging |

**Read this before using the included `MONGODB_URI`:**
- It gives full read/write access to Sales OS production data. Keep this zip private and don't commit `.env` to git.
- If the new portal runs this code against the **same** database, it uses the **same** settings document and the **same saved WhatsApp logins** (e.g. Gauri's). Two servers on one WhatsApp login knock each other off every few seconds ("conflict: replaced"), and WhatsApp may log the device out. Sales OS's 11:00 / 17:30 report would then break.
- **For a separate portal, use that portal's own database** (its own `MONGODB_URI`) and link its own WhatsApp number. Only reuse this URI if the new portal is meant to report on Sales OS data. Even then, rename the settings collection and use a different sender login.

## 9. Lessons learned (avoid these)

1. **One connection per WhatsApp login.** Never run a second server, a local dev server or a test script on the same saved login while production is connected. That's why the scheduler is production-only.
2. **Ask WhatsApp for a delivery confirmation.** `sendMessage()` returning doesn't mean the message was sent. The service waits for the server acknowledgement (`ack ≥ 2`) and reports "unconfirmed" otherwise.
3. **Groups:** the sender number must be a member of the group. If "Only admins can send" is on, it must be a group admin.
4. **Unsaved edits:** "Send now" saves edits first; reloads never overwrite what's typed.
5. **Never log out an agent's own WhatsApp from the report pop-up.** The logout route refuses when `senderUsername` points at an agent.
6. **Old settings rows** don't get schema defaults with `.lean()`. `getSettings()` fills them in.
7. **After a deploy,** mark already-sent slots in `lastSentSlots`, or a slot still inside its 3-hour late window sends again.
8. **Text fallback:** if the PNG fails, the same tables go as monospace text (`!` = red, `*` = orange).

## 10. Go-live checklist

- [ ] Report data rewritten for your portal (§4); `/preview` looks right
- [ ] Fonts installed on the Linux server
- [ ] Route + scheduler wired (§5), `NODE_ENV=production` on the server
- [ ] Button in the header for admins (§6)
- [ ] Open the pop-up → Connect WhatsApp → scan with the sender phone (or set `senderUsername`)
- [ ] Choose groups → tick the group → Save; set `sendTimes`
- [ ] Preview → Send now once → confirm it arrived in the group
