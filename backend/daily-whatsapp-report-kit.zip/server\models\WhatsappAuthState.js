import mongoose from 'mongoose';

/**
 * Baileys credential/key storage.
 *
 * Baileys ships `useMultiFileAuthState`, which writes the linked-device
 * credentials to local disk. That is unusable here: the app runs on Render's
 * free plan, whose filesystem is ephemeral and whose instances spin down after
 * ~15 minutes idle. Every deploy, restart and spin-down wiped the credentials,
 * which is why agents were asked to re-scan the QR for practically every lead.
 *
 * Keeping the same records in Mongo (which already survives restarts) means a
 * scan done once keeps working across deploys until the agent explicitly
 * unlinks the device from their phone.
 */
const WhatsappAuthStateSchema = new mongoose.Schema(
    {
        // Sanitised agent identifier, from resolveUserKey().
        userKey: { type: String, required: true, index: true },
        // 'creds', or '<signal key type>-<id>' for the signal key store.
        keyId: { type: String, required: true },
        // JSON.stringify(value, BufferJSON.replacer) — Buffers survive the round trip.
        data: { type: String, required: true },
    },
    {
        collection: 'whatsapp_auth_state',
        timestamps: true,
    }
);

WhatsappAuthStateSchema.index({ userKey: 1, keyId: 1 }, { unique: true });

const WhatsappAuthState = mongoose.model('WhatsappAuthState', WhatsappAuthStateSchema);

export default WhatsappAuthState;
