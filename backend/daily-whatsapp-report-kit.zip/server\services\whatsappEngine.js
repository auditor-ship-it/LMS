/**
 * Chooses the WhatsApp backend.
 *
 * 'baileys' (default) talks to WhatsApp over a plain WebSocket — no browser, a
 * few MB per agent, and credentials in Mongo. 'web' is the previous
 * whatsapp-web.js implementation, which drives a full headless Chrome per
 * agent; it is kept only as an escape hatch and cannot fit in Render's free
 * 512MB instance. Set WHATSAPP_ENGINE=web to fall back.
 */
const engine = String(process.env.WHATSAPP_ENGINE || 'baileys').toLowerCase();

const impl =
    engine === 'web'
        ? await import('./whatsappWebService.js')
        : await import('./whatsappBaileysService.js');

console.log(`WhatsApp engine: ${engine}`);

export const WHATSAPP_ENGINE = engine;

export const resolveUserKey = impl.resolveUserKey;
export const getWhatsAppSession = impl.getWhatsAppSession;
export const startWhatsAppSession = impl.startWhatsAppSession;
export const logoutWhatsAppSession = impl.logoutWhatsAppSession;
export const sendWhatsAppText = impl.sendWhatsAppText;
export const sendWhatsAppIntro = impl.sendWhatsAppIntro;
export const sendWhatsAppImage = impl.sendWhatsAppImage;
export const shutdownAllWhatsAppSessions = impl.shutdownAllWhatsAppSessions;
export const GOOGLE_REVIEW_QR_PATH = impl.GOOGLE_REVIEW_QR_PATH;

/** Only the Baileys engine can list / send to groups. */
export const listWhatsAppGroups =
    impl.listWhatsAppGroups ||
    (async () => {
        const err = new Error('Sending to WhatsApp groups needs WHATSAPP_ENGINE=baileys.');
        err.code = 'GROUPS_UNSUPPORTED';
        throw err;
    });

/** Only the Baileys engine can issue pairing codes. */
export const requestPairingCode =
    impl.requestPairingCode ||
    (async () => {
        const err = new Error('Pairing codes need WHATSAPP_ENGINE=baileys. Scan the QR instead.');
        err.code = 'PAIRING_UNSUPPORTED';
        throw err;
    });
